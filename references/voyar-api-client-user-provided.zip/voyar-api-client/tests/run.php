<?php

declare(strict_types=1);

/**
 * Dependency-free test runner: php tests/run.php
 */

require_once dirname(__DIR__) . '/bootstrap.php';

use Voyar\Client\Auth\InMemoryTokenStore;
use Voyar\Client\Auth\Token;
use Voyar\Client\Client;
use Voyar\Client\Exception\ApiException;
use Voyar\Client\Exception\AuthenticationException;
use Voyar\Client\Exception\PermissionDeniedException;
use Voyar\Client\Exception\RateLimitedException;
use Voyar\Client\Exception\TransportException;
use Voyar\Client\Exception\TwoFactorRequiredException;
use Voyar\Client\Exception\VerificationRequiredException;
use Voyar\Client\Exception\VoyarException;
use Voyar\Client\Http\RawResponse;
use Voyar\Client\Http\Transport;
use Voyar\Client\Model\CustomPackageSpec;

/**
 * Scripted transport: queue responses/exceptions, inspect recorded requests.
 */
final class FakeTransport implements Transport
{
    /** @var array<int, array{method:string,url:string,headers:string[],body:string|array|null}> */
    public array $requests = [];
    /** @var array<int, RawResponse|\Throwable> */
    private array $queue = [];

    /**
     * @param array<string, mixed>|string $body
     */
    public function push($body, int $status = 200): self
    {
        $this->queue[] = new RawResponse($status, is_array($body) ? json_encode($body) : $body);

        return $this;
    }

    public function pushError(\Throwable $e): self
    {
        $this->queue[] = $e;

        return $this;
    }

    public function pushFile(string $contents, string $filename): self
    {
        $this->queue[] = ['contents' => $contents, 'filename' => $filename];

        return $this;
    }

    public function send(string $method, string $url, array $headers, $body, $sink = null): RawResponse
    {
        $this->requests[] = ['method' => $method, 'url' => $url, 'headers' => $headers, 'body' => $body];
        $next = array_shift($this->queue);
        if ($next === null) {
            throw new \LogicException('FakeTransport queue is empty for ' . $method . ' ' . $url);
        }
        if ($next instanceof \Throwable) {
            throw $next;
        }
        if (is_array($next)) {
            fwrite($sink, $next['contents']);

            return new RawResponse(200, '', $next['filename']);
        }

        return $next;
    }

    public function last(): array
    {
        return $this->requests[count($this->requests) - 1];
    }
}

$passed = 0;
$failed = 0;

function check(string $name, bool $ok, string $detail = ''): void
{
    global $passed, $failed;
    if ($ok) {
        $passed++;

        return;
    }
    $failed++;
    echo "FAIL: {$name}" . ($detail !== '' ? " — {$detail}" : '') . "\n";
}

function throws(callable $fn, string $class): ?\Throwable
{
    try {
        $fn();
    } catch (\Throwable $e) {
        return $e instanceof $class ? $e : null;
    }

    return null;
}

function headerValue(array $request, string $name): ?string
{
    foreach ($request['headers'] as $line) {
        if (stripos($line, $name . ':') === 0) {
            return trim(substr($line, strlen($name) + 1));
        }
    }

    return null;
}

const BASE = 'https://api.test/client';
$ok = ['status' => 'success'];

// --- paths, methods, bodies ----------------------------------------------------------------------
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE, 'language' => 'tr'], $t);

$t->push($ok);
$voyar->service('VM-1')->vm()->start();
$r = $t->last();
check('vm start method', $r['method'] === 'POST');
check('vm start url', $r['url'] === BASE . '/services/vm/start/VM-1', $r['url']);
check('api key header', headerValue($r, 'X-Api-Key') === 'KEY');
check('language header', headerValue($r, 'X-Language') === 'tr');

$t->push($ok);
$voyar->service('VM-1')->vm()->status();
check('vm status is GET', $t->last()['method'] === 'GET' && $t->last()['url'] === BASE . '/services/vm/status/VM-1');

$t->push($ok);
$voyar->service('VM 1/../x')->vm()->start();
check('service id is url-encoded', $t->last()['url'] === BASE . '/services/vm/start/VM%201%2F..%2Fx', $t->last()['url']);

$t->push($ok);
$voyar->service('VM-1')->backups()->delete('local:backup/vzdump-1', 'local');
$r = $t->last();
parse_str((string) $r['body'], $body);
check('backup delete path has service id', $r['url'] === BASE . '/services/backups/delete/VM-1', $r['url']);
check('backup delete body', $body === ['volid' => 'local:backup/vzdump-1', 'storage' => 'local'], json_encode($body));
check('form content type', headerValue($r, 'Content-Type') === 'application/x-www-form-urlencoded');

$t->push($ok);
$voyar->service('VM-1')->backups()->create();
parse_str((string) $t->last()['body'], $body);
check('backup create default mode', $body === ['mode' => 'snapshot']);

$t->push($ok);
$voyar->services()->oneClickTask(42);
check('oneclick status uses task id', $t->last()['url'] === BASE . '/services/oneclicks/status/42');

$t->push($ok);
$voyar->service('VM-1')->addons()->remove(7);
check('addon remove path', $t->last()['url'] === BASE . '/services/services/addons/remove/VM-1/7');

$t->push($ok);
$voyar->service('VM-1')->extend(['days' => 30]);
check('extend path', $t->last()['url'] === BASE . '/services/services/extend/VM-1');

$t->push($ok);
$voyar->service('VM-1')->vm()->graphs(['timeframe' => 'hour']);
check('graphs query string', $t->last()['url'] === BASE . '/services/vm/graphs/VM-1?timeframe=hour', $t->last()['url']);

// scopes must not leak ids
$a = $voyar->service('A');
$b = $voyar->service('B');
$t->push($ok)->push($ok);
$a->vm()->start();
$b->vm()->start();
check('scopes do not leak ids', $t->requests[count($t->requests) - 2]['url'] === BASE . '/services/vm/start/A' && $t->last()['url'] === BASE . '/services/vm/start/B');
check('empty service id rejected', throws(static fn() => $voyar->service(' '), VoyarException::class) !== null);

// --- catalog / custom package --------------------------------------------------------------------
$t->push($ok);
$voyar->catalog()->products()->search();
check('products search is public (no api key)', headerValue($t->last(), 'X-Api-Key') === null);

$t->push(['status' => 'success', 'data' => ['usd' => 41.5]]);
$rate = $voyar->publicData()->exchangeRate();
check('exchange rate url', $t->last()['method'] === 'GET' && $t->last()['url'] === BASE . '/public/exchange-rate', $t->last()['url']);
check('exchange rate is public (no api key)', headerValue($t->last(), 'X-Api-Key') === null);
check('exchange rate payload', ($rate['data']['usd'] ?? null) === 41.5);

$t->push($ok);
$voyar->catalog()->customPackage()->options(3);
check('custom package options url', $t->last()['url'] === BASE . '/resources/custom-package/options?product_group_id=3');
check('custom package options is authenticated', headerValue($t->last(), 'X-Api-Key') === 'KEY');

$t->push($ok);
$voyar->catalog()->customPackage()->quote(new CustomPackageSpec(3, 4, 8, 80, 1), 'prepaid');
parse_str((string) $t->last()['body'], $body);
check('quote body', $body === ['custom_package' => ['product_group_id' => '3', 'cpu_cores' => '4', 'ram_gb' => '8', 'disk_gb' => '80', 'ipv4_count' => '1'], 'billing_type' => 'prepaid'], json_encode($body));

$t->push($ok);
$voyar->catalog()->processorFamilies()->stock(5, 2);
check('processor families url', $t->last()['url'] === BASE . '/resources/processor-families/stock?pid=5&locationid=2');

$t->push($ok);
$voyar->catalog()->gpu()->search(['pid' => 5, 'locationid' => 2]);
check('gpu search url', $t->last()['url'] === BASE . '/resources/gpu/search?pid=5&locationid=2', $t->last()['url']);
check('gpu search is authenticated', headerValue($t->last(), 'X-Api-Key') === 'KEY');

$t->push($ok);
$voyar->service('VM-1')->gpuOptions();
check('gpu options url', $t->last()['method'] === 'GET' && $t->last()['url'] === BASE . '/services/services/gpu-options/VM-1', $t->last()['url']);

$t->push($ok);
$voyar->service('VM-1')->vm()->gpuUsage();
check('gpu usage url', $t->last()['method'] === 'GET' && $t->last()['url'] === BASE . '/services/vm/gpu-usage/VM-1', $t->last()['url']);

$t->push($ok);
$voyar->services()->ftpCustomConfig();
check('ftp custom config url', $t->last()['method'] === 'GET' && $t->last()['url'] === BASE . '/services/ftp/custom/config', $t->last()['url']);

$t->push($ok);
$voyar->services()->ftpCustomQuote(750);
check('ftp custom quote url', $t->last()['url'] === BASE . '/services/ftp/custom/quote?gb=750', $t->last()['url']);

$t->push($ok);
$voyar->service('VM-1')->privateNetwork()->allow('VM-2');
parse_str((string) $t->last()['body'], $body);
check('private network allow', $t->last()['method'] === 'POST' && $t->last()['url'] === BASE . '/services/private-network/allow/VM-1' && $body === ['service' => 'VM-2'], $t->last()['url']);

check('invalid spec rejected', throws(static fn() => new CustomPackageSpec(1, 0, 4, 40), VoyarException::class) !== null);
check('spec toArray', (new CustomPackageSpec(1, 2, 4, 40, 0))->toArray() === ['product_group_id' => 1, 'cpu_cores' => 2, 'ram_gb' => 4, 'disk_gb' => 40, 'ipv4_count' => 0]);

// --- error mapping -------------------------------------------------------------------------------
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE], $t);

$t->push(['status' => 'failed', 'message' => 'nope', 'error' => 'some_code']);
$e = throws(static fn() => $voyar->service('V')->get(), ApiException::class);
check('api exception', $e instanceof ApiException && $e->getMessage() === 'nope' && $e->getErrorCode() === 'some_code' && !$e->shouldLogout());

$t->push(['status' => 'failed', 'message' => 'denied', 'error' => 'permission_denied', 'required_permission' => 'vm.start'], 403);
$e = throws(static fn() => $voyar->service('V')->vm()->start(), PermissionDeniedException::class);
check('permission denied', $e instanceof PermissionDeniedException && $e->getRequiredPermission() === 'vm.start');

$t->push(['status' => 'failed', 'message' => 'slow down', 'error_code' => 'too_many_requests', 'retry_after' => 120], 429);
$sent = count($t->requests);
$e = throws(static fn() => $voyar->service('V')->get(), RateLimitedException::class);
check('rate limited, no retry', $e instanceof RateLimitedException && $e->getRetryAfter() === 120 && $e->getHttpStatus() === 429 && count($t->requests) === $sent + 1);

$t->push(['status' => 'failed', 'message' => 'expired', 'logout' => true], 401);
$e = throws(static fn() => $voyar->service('V')->get(), AuthenticationException::class);
check('auth exception, no credentials => no retry', $e instanceof AuthenticationException && $e->shouldLogout());

$t->push(['status' => 'failed', 'message' => 'code', 'partial_token' => 'PT', 'partial_token_expires_at' => '2030-01-01 00:00:00']);
$e = throws(static fn() => $voyar->service('V')->get(), TwoFactorRequiredException::class);
check('2fa exception', $e instanceof TwoFactorRequiredException && $e->getPartialToken() === 'PT');

$t->push(['status' => 'failed', 'message' => 'verify', 'error' => 'verification_required', 'verification' => ['type' => 'phone']]);
$e = throws(static fn() => $voyar->service('V')->get(), VerificationRequiredException::class);
check('verification exception', $e instanceof VerificationRequiredException && $e->getVerification() === ['type' => 'phone']);

$before = count($t->requests);
$t->push('<html>bad gateway</html>', 502);
$e = throws(static fn() => $voyar->service('V')->vm()->start(), TransportException::class);
check('non-json => transport exception, POST not retried', $e !== null && count($t->requests) - $before === 1, 'requests=' . (count($t->requests) - $before));

// --- GET retries ---------------------------------------------------------------------------------
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE, 'max_retries' => 2], $t);

$t->pushError(new TransportException('timeout'))->push($ok);
$voyar->service('V')->get();
check('GET retried after transport error', count($t->requests) === 2);

$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE, 'max_retries' => 2], $t);
$t->push('oops', 503)->push('oops', 503)->push($ok);
$voyar->service('V')->get();
check('GET retried on 5xx', count($t->requests) === 3);

$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE, 'max_retries' => 1], $t);
$t->pushError(new TransportException('down'));
$e = throws(static fn() => $voyar->service('V')->vm()->start(), TransportException::class);
check('POST not retried on transport error', $e !== null && count($t->requests) === 1);

$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE, 'max_retries' => 1], $t);
$t->pushError(new TransportException('a'))->pushError(new TransportException('b'));
$e = throws(static fn() => $voyar->service('V')->get(), TransportException::class);
check('GET gives up after max_retries', $e !== null && count($t->requests) === 2);

// --- credentials: lazy login, store reuse, re-auth ----------------------------------------------
$login = static function (string $token, string $expires): array {
    return ['status' => 'success', 'token' => ['token' => $token, 'expired_at' => $expires]];
};
$future = date('Y-m-d H:i:s', time() + 3600);

$t = new FakeTransport();
$store = new InMemoryTokenStore();
$voyar = Client::withCredentials('a@b.c', 'secret', $store, ['base_url' => BASE], $t);
check('no request at construction', count($t->requests) === 0);

$t->push($login('T1', $future))->push($ok)->push($ok);
$voyar->service('V')->get();
check('lazy login first', $t->requests[0]['url'] === BASE . '/auth/login' && headerValue($t->requests[0], 'X-Api-Key') === null);
parse_str((string) $t->requests[0]['body'], $body);
check('login body', $body === ['email' => 'a@b.c', 'password' => 'secret']);
check('then real call with token', headerValue($t->requests[1], 'X-Api-Key') === 'T1');
$voyar->service('V')->get();
check('token reused (no second login)', count($t->requests) === 3 && headerValue($t->requests[2], 'X-Api-Key') === 'T1');
check('store has token', $store->get() !== null && $store->get()->value() === 'T1');
check('apiKey() exposes token', $voyar->apiKey() === 'T1');

// a second client sharing the store does not log in again
$t2 = new FakeTransport();
$voyar2 = Client::withCredentials('a@b.c', 'secret', $store, ['base_url' => BASE], $t2);
$t2->push($ok);
$voyar2->service('V')->get();
check('shared store skips login', count($t2->requests) === 1 && headerValue($t2->requests[0], 'X-Api-Key') === 'T1');

// expired token in store => login again before the call
$t = new FakeTransport();
$store = new InMemoryTokenStore();
$store->save(new Token('OLD', time() - 10));
$voyar = Client::withCredentials('a@b.c', 'secret', $store, ['base_url' => BASE], $t);
$t->push($login('NEW', $future))->push($ok);
$voyar->service('V')->get();
check('expired token triggers login', $t->requests[0]['url'] === BASE . '/auth/login' && headerValue($t->requests[1], 'X-Api-Key') === 'NEW');

// server says logout => re-login once and retry once
$t = new FakeTransport();
$store = new InMemoryTokenStore();
$store->save(new Token('STALE', time() + 3600));
$voyar = Client::withCredentials('a@b.c', 'secret', $store, ['base_url' => BASE], $t);
$t->push(['status' => 'failed', 'message' => 'expired', 'logout' => true], 401)
    ->push($login('FRESH', $future))
    ->push($ok);
$res = $voyar->service('V')->get();
check('re-auth once then success', count($t->requests) === 3 && $res['status'] === 'success' && headerValue($t->requests[2], 'X-Api-Key') === 'FRESH');

// logout again after re-auth => no loop
$t = new FakeTransport();
$store = new InMemoryTokenStore();
$store->save(new Token('STALE', time() + 3600));
$voyar = Client::withCredentials('a@b.c', 'secret', $store, ['base_url' => BASE], $t);
$t->push(['status' => 'failed', 'message' => 'expired', 'logout' => true], 401)
    ->push($login('FRESH', $future))
    ->push(['status' => 'failed', 'message' => 'expired again', 'logout' => true], 401);
$e = throws(static fn() => $voyar->service('V')->get(), AuthenticationException::class);
check('no re-auth loop', $e !== null && count($t->requests) === 3);

// bad password is a plain ApiException, not retried
$t = new FakeTransport();
$voyar = Client::withCredentials('a@b.c', 'wrong', null, ['base_url' => BASE], $t);
$t->push(['status' => 'failed', 'message' => 'Invalid credentials']);
$e = throws(static fn() => $voyar->service('V')->get(), ApiException::class);
check('login failure surfaces', $e !== null && $e->getMessage() === 'Invalid credentials' && count($t->requests) === 1);

// login that needs 2FA
$t = new FakeTransport();
$voyar = Client::withCredentials('a@b.c', 'secret', null, ['base_url' => BASE], $t);
$t->push(['status' => 'success', 'tfa_required' => true, 'partial_token' => 'PT2']);
$e = throws(static fn() => $voyar->service('V')->get(), TwoFactorRequiredException::class);
check('2fa on lazy login', $e instanceof TwoFactorRequiredException && $e->getPartialToken() === 'PT2');

// manual auth flow stores the token only when complete
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE], $t);
$t->push(['status' => 'success', 'tfa_required' => true, 'partial_token' => 'PT3', 'token' => ['token' => 'PARTIAL']]);
$voyar->auth()->login('a@b.c', 'secret');
check('2fa step does not replace token', $voyar->apiKey() === 'KEY');
$t->push($login('FULL', $future));
$voyar->auth()->tfaVerify('PT3', '123456', true);
parse_str((string) $t->last()['body'], $body);
check('tfa body', $body === ['partial_token' => 'PT3', 'code' => '123456', 'trust_this_device' => '1']);
check('tfa success stores token', $voyar->apiKey() === 'FULL');

// --- missing credentials ------------------------------------------------------------------------
$t = new FakeTransport();
$voyar = new Client(new Voyar\Client\Http\HttpClient(Voyar\Client\Config::fromArray(['base_url' => BASE]), $t));
$e = throws(static fn() => $voyar->service('V')->get(), AuthenticationException::class);
check('no key and no credentials => clear error, no request', $e !== null && count($t->requests) === 0);
check('empty email rejected', throws(static fn() => Client::withCredentials('', 'x'), VoyarException::class) !== null);

// --- files -------------------------------------------------------------------------------------
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE], $t);

$sink = fopen('php://memory', 'w+b');
$t->pushFile('conf', 'laptop.conf');
$name = $voyar->service('VPN-1')->vpn()->downloadProfile(7, $sink);
rewind($sink);
check('download writes the file to the sink', $name === 'laptop.conf' && stream_get_contents($sink) === 'conf');
check('download url', $t->last()['url'] === BASE . '/services/vpn/profiles/download/VPN-1/7');

$sink = fopen('php://memory', 'w+b');
$t->push(['status' => 'failed', 'message' => 'File not found.']);
$e = throws(static fn() => $voyar->service('FTP-1')->ftp()->download('a/b.txt', $sink), ApiException::class);
rewind($sink);
check('download error is thrown, sink untouched', $e !== null && $e->getMessage() === 'File not found.' && stream_get_contents($sink) === '');
check('download path is a query parameter', $t->last()['url'] === BASE . '/services/ftp/files/download/FTP-1?path=a%2Fb.txt');

$t->pushError(new TransportException('reset'));
check('download is not retried', throws(static fn() => $voyar->service('FTP-1')->ftp()->download('a', $sink), TransportException::class) !== null);

$t->push($ok);
$voyar->service('FTP-1')->ftp()->upload('docs', __FILE__, 'run.php');
$r = $t->last();
check('upload is multipart', $r['url'] === BASE . '/services/ftp/files/upload/FTP-1' && is_array($r['body']) && headerValue($r, 'Content-Type') === null);
check('upload fields', $r['body']['path'] === 'docs' && $r['body']['file'] instanceof CURLFile && $r['body']['file']->getPostFilename() === 'run.php');

$t->push($ok);
$voyar->service('FTP-1')->ftp()->updateSubuser(4, 'S3cret!');
check('ftp sub-user path', $t->last()['url'] === BASE . '/services/ftp/subusers/update/FTP-1/4' && $t->last()['body'] === 'password=S3cret%21');

$t->push($ok);
$voyar->service('FTP-1')->lock();
check('lock path', $t->last()['method'] === 'POST' && $t->last()['url'] === BASE . '/services/services/lock/FTP-1');

// --- logger redaction ---------------------------------------------------------------------------
$t = new FakeTransport();
$voyar = Client::withApiKey('KEY', ['base_url' => BASE], $t);
$logged = [];
$voyar->setLogger(static function (string $message, array $context) use (&$logged): void {
    $logged[] = [$message, $context];
});
$t->push($ok);
$voyar->service('V')->vm()->password(['password' => 'Hunter2!']);
check('logger called', count($logged) === 1 && $logged[0][0] === 'POST /services/vm/password/V');
check('logger masks password', ($logged[0][1]['password'] ?? null) === '***' && strpos(json_encode($logged), 'Hunter2') === false);
check('logger never sees api key', strpos(json_encode($logged), 'KEY') === false);

// --- token value object -------------------------------------------------------------------------
check('token without expiry never expires', !(new Token('x'))->isExpired());
check('token expiry skew', (new Token('x', time() + 30))->isExpired(60) && !(new Token('x', time() + 300))->isExpired(60));
check('token from string response', Token::fromResponse(['token' => 'abc'])->value() === 'abc');
check('token from partial response', Token::fromResponse(['partial_token' => 'p']) === null);

echo "\n{$passed} passed, {$failed} failed\n";
exit($failed === 0 ? 0 : 1);
