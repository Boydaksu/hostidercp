# Voyar Client API — PHP SDK

Voyar Client API için bağımlılıksız PHP kütüphanesi (WHMCS, WiseCP, cron/otomasyon). PHP 7.4+, `ext-curl`, `ext-json`.

## Kurulum

```json
{
  "repositories": [{ "type": "path", "url": "packages/voyar-api-client" }],
  "require": { "voyar/api-client": "@dev" }
}
```

Composer'sız: `require_once '/path/to/voyar-api-client/bootstrap.php';`

## Hızlı Başlangıç

```php
use Voyar\Client\Client;

// Statik token
$voyar = Client::withApiKey($token, ['language' => 'tr']);

// E-posta + parola: ilk istekte login olur, token süresi dolunca / API "logout" deyince
// kendiliğinden yeniden login olur ve isteği bir kez tekrarlar.
$voyar = Client::withCredentials($email, $password, $tokenStore, ['language' => 'tr']);

$voyar->catalog()->products()->search();
$voyar->service('VM-123456')->vm()->start();
$voyar->service('VM-123456')->backups()->create('snapshot');
```

Seçenekler (`$options`): `base_url` (varsayılan `https://api.voyar.net/client`), `language`, `timeout` (30), `connect_timeout` (10),
`verify_ssl` (true), `max_retries` (2, yalnızca GET), `user_agent`.

## Yapı

| Giriş | Açıklama |
|-------|----------|
| `$voyar->auth()` | `/auth/*` — manuel login, 2FA, token bilgisi |
| `$voyar->catalog()` | `/resources/*` — ürünler, ürün grupları, addon, lokasyon, OS, işlemci ailesi, **custom package** |
| `$voyar->publicData()` | `/public/*` — giriş gerektirmeyen veriler: döviz kuru (`exchangeRate()`) |
| `$voyar->services()` | `/services/*` koleksiyon seviyesi — arama, sipariş, görevler, VPN siparişi |
| `$voyar->service($publicId)` | **Tek bir servis** — `get/extend/upgrade/terminate…` ve `vm() iso() firewall() privateNetwork() waf() backups() rdns() oneClick() addons() vpn()` |

`service($id)` değişmezdir: id oluşturulurken sabitlenir, paylaşılan/mutasyona uğrayan durum yoktur.

```php
$a = $voyar->service('VM-1');
$b = $voyar->service('VM-2');
$a->vm()->start();   // VM-1
$b->vm()->start();   // VM-2
```

Yanıtlar API zarfının dizisi olarak döner (`['status' => 'success', ...]`). `status != success` ise exception fırlatılır.

## Kimlik doğrulama ve token saklama

`Client::withCredentials()` ikinci bağımsız değişken olarak `TokenStore` alır. Varsayılan bellek içidir; PHP-FPM/WHMCS gibi
her istekte yeniden başlayan ortamlarda DB/cache tabanlı bir store verin ki her istekte login olunmasın:

```php
final class DbTokenStore implements \Voyar\Client\Auth\TokenStore
{
    public function get(): ?\Voyar\Client\Auth\Token { /* satırı oku */ }
    public function save(\Voyar\Client\Auth\Token $t): void { /* $t->value(), $t->expiresAt() */ }
    public function clear(): void { /* sil */ }
}
```

> API token'ları oluşturuldukları IP'ye bağlıdır ve **6 saat** geçerlidir; modül kendi sunucusundan login olmalıdır.

2FA'lı hesaplarda `withCredentials` ilk istekte `TwoFactorRequiredException` fırlatır (`getPartialToken()`); `auth()->tfaVerify()` ile tamamlayın.

## Custom package

```php
use Voyar\Client\Model\CustomPackageSpec;

$cp = $voyar->catalog()->customPackage();
$options = $cp->options(3);                                  // cpu/ram/disk/ipv4 aralıkları ve oranlar
$quote   = $cp->quote(new CustomPackageSpec(3, 4, 8, 80, 1), 'prepaid');   // saatlik/günlük maliyet

$voyar->services()->create([
    'custom_package' => (new CustomPackageSpec(3, 4, 8, 80, 1))->toArray(),
    'osid' => 12, 'locationid' => 2, 'type' => 'prepaid', 'days' => 30,
    'processor_family' => 'amd',
]);
```

Custom paket servisleri `upgrade` ile başka ürüne taşınamaz.

## Hata yönetimi

```
VoyarException
├── TransportException              ağ hatası / JSON olmayan yanıt
└── ApiException                    status != success   (getErrorCode, getHttpStatus, getResponse, shouldLogout)
    ├── AuthenticationException     401 / logout / auth_provider_*  (SDK önce yeniden login dener)
    ├── TwoFactorRequiredException  getPartialToken(), getPartialTokenExpiresAt()
    ├── PermissionDeniedException   403, getRequiredPermission()
    ├── RateLimitedException        429 (istek limiti veya hatalı deneme banı), getRetryAfter() saniye kadar bekleyin
    └── VerificationRequiredException  getVerification()
```

## Logger

```php
$voyar->setLogger(function (string $message, array $context) {
    error_log('[Voyar] ' . $message . ' ' . json_encode($context));
});
```

Parola, token, kod gibi alanlar `***` ile maskelenir; API anahtarı hiçbir zaman loglanmaz.

## Test

```bash
php tests/run.php
```

`Transport` arayüzü sayesinde testler ağsız çalışır (`FakeTransport`). Kendi HTTP istemcinizi `Voyar\Client\Http\Transport`
ile bağlayıp `new Client(new HttpClient($config, $transport, $store, $credentials))` ile kullanabilirsiniz.

## Dokümantasyon

[auth](docs/auth.md) · [services](docs/services.md) · [vm](docs/vm.md) · [resources](docs/resources.md) · [iso](docs/iso.md) ·
[firewall](docs/firewall.md) · [private network](docs/private-network.md) · [waf](docs/waf.md) · [rdns](docs/rdns.md) · [backup](docs/backup.md) ·
[oneclick](docs/oneclick.md) · [tasks](docs/tasks.md) · [vpn](docs/vpn.md) · [ftp](docs/ftp.md) · çalıştırılabilir senaryolar: [examples/](examples/README.md)

## v1'den geçiş

| v1 | v2 |
|----|----|
| `new Client(['api_key'=>…])` | `Client::withApiKey($key)` |
| `new Client(['email'=>…,'password'=>…])` | `Client::withCredentials($email, $password, $store)` |
| `$c->services->vm->id($id)->start()` | `$c->service($id)->vm()->start()` |
| `$c->services->services->get($id)` | `$c->service($id)->get()` |
| `$c->services->services->search()` | `$c->services()->search()` |
| `$c->services->services->addons->assign($id, $d)` | `$c->service($id)->addons()->assign($addonId, $qty)` |
| `$c->resources->products->search()` | `$c->catalog()->products()->search()` |
| `$c->resources->operatingsystems->index()` | `$c->catalog()->operatingSystems()->index()` |
| `AuthException` | `TwoFactorRequiredException` / `AuthenticationException` |
| `backups->delete($volid…)` (hatalı path) | `service($id)->backups()->delete($volid, $storage)` |
| `oneclicks->status()` (servis id) | `services()->oneClickTask($taskId)` |
