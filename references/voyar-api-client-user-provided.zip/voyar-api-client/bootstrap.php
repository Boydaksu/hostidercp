<?php

declare(strict_types=1);

if (defined('VOYAR_CLIENT_BOOTSTRAPPED')) {
    return;
}

define('VOYAR_CLIENT_BOOTSTRAPPED', true);

spl_autoload_register(static function (string $class): void {
    $prefix = 'Voyar\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    $relative = str_replace('\\', DIRECTORY_SEPARATOR, substr($class, strlen($prefix)));
    $file = __DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'Voyar' . DIRECTORY_SEPARATOR . $relative . '.php';

    if (is_file($file)) {
        require $file;
    }
});
