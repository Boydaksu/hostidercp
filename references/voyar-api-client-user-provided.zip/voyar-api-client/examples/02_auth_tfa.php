<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';

use Voyar\Client\Client;

// Manual two-step login: php 02_auth_tfa.php <email> <password> <code>
[$script, $email, $password, $code] = array_pad($argv, 4, '');
if ($email === '' || $password === '') {
    fwrite(STDERR, "Usage: php {$script} <email> <password> [code]\n");
    exit(1);
}

$voyar = Client::withApiKey('unused-until-login');
$response = $voyar->auth()->login($email, $password);

if (!empty($response['tfa_required'])) {
    if ($code === '') {
        echo "2FA code required. Re-run with the code as third argument.\n";
        exit(0);
    }
    $response = $voyar->auth()->tfaVerify((string) $response['partial_token'], $code, true);
}

echo 'Logged in. Token expires at ' . ($response['token']['expired_at'] ?? '?') . "\n";
