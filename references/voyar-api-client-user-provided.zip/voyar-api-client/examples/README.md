# Örnekler

Her script `bootstrap.php` ile client oluşturur. Ortam değişkenleri:

| Değişken | Açıklama |
|----------|----------|
| `VOYAR_API_KEY` | Statik token **veya** |
| `VOYAR_EMAIL` + `VOYAR_PASSWORD` | Login |
| `VOYAR_BASE_URL` | Varsayılan `https://api.voyar.net/client` |
| `VOYAR_LANGUAGE` | `tr`, `en`, … |
| `VOYAR_SERVICE_ID` | Servis scriptleri için (örn. `VM-123456`) |

| Dosya | Senaryo |
|-------|---------|
| `01_auth_login.php` | Token bilgisi |
| `02_auth_tfa.php` | Manuel login + 2FA |
| `03_catalog_browse.php` | Ürün, lokasyon, OS, ürün grupları, custom package seçenekleri |
| `04_custom_package.php` | Custom paket fiyat teklifi |
| `05_vm_power_management.php` | Durum / güç |
| `06_firewall_and_backups.php` | Firewall + yedekler |
| `07_error_handling.php` | Exception hiyerarşisi |

```bash
VOYAR_API_KEY=... php examples/03_catalog_browse.php
```

Scriptler varsayılan olarak yalnızca okuma yapar; yazma çağrıları yorum satırındadır.
