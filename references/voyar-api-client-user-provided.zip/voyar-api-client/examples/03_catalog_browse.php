<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$voyar = voyar_example_client();
$catalog = $voyar->catalog();

voyar_example_print('products', $catalog->products()->search());
voyar_example_print('locations', $catalog->locations()->search());
voyar_example_print('operating systems', $catalog->operatingSystems()->index());

$groups = $catalog->productGroups()->search();
voyar_example_print('product groups', $groups);

foreach ($groups['productgroups']['data'] ?? [] as $group) {
    if (empty($group['custom_builder_enabled'])) {
        continue;
    }
    voyar_example_print('custom package options: ' . $group['name'], $catalog->customPackage()->options((int) $group['id']));
}
