<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';

use Voyar\Client\Client;

/**
 * Shared client factory for the example scripts.
 *
 * Environment:
 *   VOYAR_API_KEY            static token (preferred for cron/modules), or
 *   VOYAR_EMAIL + VOYAR_PASSWORD
 *   VOYAR_BASE_URL           default https://api.voyar.net/client
 *   VOYAR_LANGUAGE           optional (tr, en, ...)
 *   VOYAR_SERVICE_ID         for the per-service examples (e.g. VM-123456)
 */
function voyar_example_client(): Client
{
    $options = ['base_url' => getenv('VOYAR_BASE_URL') ?: 'https://api.voyar.net/client'];

    $language = getenv('VOYAR_LANGUAGE') ?: '';
    if ($language !== '') {
        $options['language'] = $language;
    }

    $apiKey = getenv('VOYAR_API_KEY') ?: '';
    if ($apiKey !== '') {
        return Client::withApiKey($apiKey, $options);
    }

    $email = getenv('VOYAR_EMAIL') ?: '';
    $password = getenv('VOYAR_PASSWORD') ?: '';
    if ($email === '' || $password === '') {
        fwrite(STDERR, "Set VOYAR_API_KEY or VOYAR_EMAIL + VOYAR_PASSWORD.\n");
        exit(1);
    }

    return Client::withCredentials($email, $password, null, $options);
}

/**
 * @param mixed $data
 */
function voyar_example_print(string $title, $data): void
{
    echo "\n=== {$title} ===\n";
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
}

function voyar_example_service_id(): string
{
    $id = getenv('VOYAR_SERVICE_ID') ?: '';
    if ($id === '') {
        fwrite(STDERR, "Set VOYAR_SERVICE_ID (e.g. VM-123456) for this example.\n");
        exit(1);
    }

    return $id;
}
