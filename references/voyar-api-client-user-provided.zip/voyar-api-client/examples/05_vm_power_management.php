<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$voyar = voyar_example_client();
$vm = $voyar->service(voyar_example_service_id())->vm();

voyar_example_print('status', $vm->status());
voyar_example_print('loadavg', $vm->loadavg());

// $vm->start(); $vm->restart(); $vm->stop();
