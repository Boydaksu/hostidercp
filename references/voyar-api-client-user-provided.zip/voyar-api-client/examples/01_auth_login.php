<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use Voyar\Client\Exception\TwoFactorRequiredException;

$voyar = voyar_example_client();

try {
    voyar_example_print('token', $voyar->auth()->token());
} catch (TwoFactorRequiredException $e) {
    echo "2FA required. Run 02_auth_tfa.php with partial token: " . $e->getPartialToken() . "\n";
}
