<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$voyar = voyar_example_client();
$service = $voyar->service(voyar_example_service_id());

voyar_example_print('firewall rules', $service->firewall()->rules());
voyar_example_print('backups', $service->backups()->list());

// $service->backups()->create('snapshot');
