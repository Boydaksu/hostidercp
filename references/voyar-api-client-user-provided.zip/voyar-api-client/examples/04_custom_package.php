<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use Voyar\Client\Model\CustomPackageSpec;

// php 04_custom_package.php <product_group_id> <cpu> <ram_gb> <disk_gb> [ipv4]
[$script, $group, $cpu, $ram, $disk, $ipv4] = array_pad($argv, 6, '');
if ($group === '' || $cpu === '' || $ram === '' || $disk === '') {
    fwrite(STDERR, "Usage: php {$script} <product_group_id> <cpu> <ram_gb> <disk_gb> [ipv4]\n");
    exit(1);
}

$voyar = voyar_example_client();
$spec = new CustomPackageSpec((int) $group, (int) $cpu, (int) $ram, (int) $disk, $ipv4 === '' ? 1 : (int) $ipv4);

$quote = $voyar->catalog()->customPackage()->quote($spec, 'prepaid')['quote'];
voyar_example_print('quote', $quote);

if (empty($quote['valid'])) {
    echo 'Invalid selection: ' . ($quote['reason'] ?? '?') . "\n";
    exit(1);
}

// Ordering is intentionally not done here. To order:
// $voyar->services()->create(['custom_package' => $spec->toArray(), 'osid' => ..., 'locationid' => ..., 'type' => 'prepaid', 'days' => 30]);
