<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use Voyar\Client\Exception\ApiException;
use Voyar\Client\Exception\AuthenticationException;
use Voyar\Client\Exception\PermissionDeniedException;
use Voyar\Client\Exception\TransportException;
use Voyar\Client\Exception\TwoFactorRequiredException;

$voyar = voyar_example_client();

try {
    $voyar->service('VM-DOES-NOT-EXIST')->get();
} catch (PermissionDeniedException $e) {
    echo 'Missing permission: ' . $e->getRequiredPermission() . "\n";
} catch (TwoFactorRequiredException $e) {
    echo 'Needs 2FA, partial token: ' . $e->getPartialToken() . "\n";
} catch (AuthenticationException $e) {
    echo 'Not authenticated: ' . $e->getMessage() . "\n";
} catch (ApiException $e) {
    echo 'API error [' . ($e->getErrorCode() ?? 'n/a') . '] HTTP ' . $e->getHttpStatus() . ': ' . $e->getMessage() . "\n";
} catch (TransportException $e) {
    echo 'Network problem: ' . $e->getMessage() . "\n";
}
