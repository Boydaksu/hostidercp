<?php

declare(strict_types=1);

namespace Voyar\Client;

use Voyar\Client\Api\Auth;
use Voyar\Client\Api\Catalog;
use Voyar\Client\Api\PublicData;
use Voyar\Client\Api\Service;
use Voyar\Client\Api\Services;
use Voyar\Client\Auth\Credentials;
use Voyar\Client\Auth\TokenStore;
use Voyar\Client\Exception\VoyarException;
use Voyar\Client\Http\HttpClient;
use Voyar\Client\Http\Transport;

/**
 * Voyar Client API entry point.
 *
 *   $voyar = Client::withCredentials($email, $password);   // logs in lazily, re-logs in when the token expires
 *   $voyar = Client::withApiKey($token);                    // static token
 *   $voyar->service('VM123')->vm()->start();
 *   $voyar->catalog()->products()->search();
 */
final class Client
{
    private HttpClient $http;

    public function __construct(HttpClient $http)
    {
        $this->http = $http;
    }

    /**
     * @param array<string, mixed> $options see Config::fromArray()
     */
    public static function withApiKey(string $apiKey, array $options = [], ?Transport $transport = null): self
    {
        $config = Config::fromArray(['api_key' => $apiKey] + $options);

        return new self(new HttpClient($config, $transport));
    }

    /**
     * @param array<string, mixed> $options see Config::fromArray()
     * @param TokenStore|null      $tokens  share the login between requests/processes (DB, cache...)
     */
    public static function withCredentials(
        string $email,
        string $password,
        ?TokenStore $tokens = null,
        array $options = [],
        ?Transport $transport = null
    ): self {
        if (trim($email) === '' || $password === '') {
            throw new VoyarException('Email and password are required.');
        }

        $config = Config::fromArray($options);

        return new self(new HttpClient($config, $transport, $tokens, new Credentials($email, $password)));
    }

    /**
     * @param callable|null $logger function (string $message, array $context): void — secrets are masked
     */
    public function setLogger(?callable $logger): self
    {
        $this->http->setLogger($logger);

        return $this;
    }

    public function auth(): Auth
    {
        return new Auth($this->http);
    }

    public function catalog(): Catalog
    {
        return new Catalog($this->http);
    }

    public function publicData(): PublicData
    {
        return new PublicData($this->http);
    }

    public function services(): Services
    {
        return new Services($this->http);
    }

    /**
     * @param string $publicId service public id (e.g. VM-123456)
     */
    public function service(string $publicId): Service
    {
        return new Service($this->http, $publicId);
    }

    /**
     * Current token value (null before the first authenticated call).
     */
    public function apiKey(): ?string
    {
        $token = $this->http->token();

        return $token !== null ? $token->value() : null;
    }
}
