<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * Base class for every exception thrown by the SDK.
 */
class VoyarException extends \Exception
{
}
