<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * HTTP 429: the request rate limit was exceeded or the IP is banned on the endpoint after repeated failed
 * attempts (response `reason`: rate_limit | failed_attempts). Wait getRetryAfter() seconds before calling again.
 */
class RateLimitedException extends ApiException
{
    private int $retryAfter;

    /**
     * @param array<string, mixed> $response
     */
    public function __construct(string $message, int $retryAfter = 0, array $response = [])
    {
        parent::__construct($message, 'too_many_requests', 429, false, $response);
        $this->retryAfter = $retryAfter;
    }

    /**
     * Seconds until the limit or ban ends, 0 when the API did not say.
     */
    public function getRetryAfter(): int
    {
        return $this->retryAfter;
    }
}
