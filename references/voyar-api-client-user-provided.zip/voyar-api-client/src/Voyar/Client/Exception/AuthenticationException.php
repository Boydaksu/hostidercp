<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * Token missing/expired/invalid (HTTP 401 or `logout: true`) or an auth provider failure.
 */
class AuthenticationException extends ApiException
{
    /**
     * @param array<string, mixed> $response
     */
    public function __construct(string $message, ?string $errorCode = null, int $httpStatus = 401, array $response = [])
    {
        parent::__construct($message, $errorCode, $httpStatus, true, $response);
    }
}
