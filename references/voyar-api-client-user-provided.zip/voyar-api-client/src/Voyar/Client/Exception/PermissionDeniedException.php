<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

class PermissionDeniedException extends ApiException
{
    private ?string $requiredPermission;

    /**
     * @param array<string, mixed> $response
     */
    public function __construct(string $message, ?string $requiredPermission = null, array $response = [])
    {
        parent::__construct($message, 'permission_denied', 403, false, $response);
        $this->requiredPermission = $requiredPermission;
    }

    public function getRequiredPermission(): ?string
    {
        return $this->requiredPermission;
    }
}
