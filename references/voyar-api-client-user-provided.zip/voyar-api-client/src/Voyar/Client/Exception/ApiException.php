<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * The API answered with status != success.
 */
class ApiException extends VoyarException
{
    private ?string $errorCode;
    private int $httpStatus;
    private bool $logout;
    /** @var array<string, mixed> */
    private array $response;

    /**
     * @param array<string, mixed> $response
     */
    public function __construct(
        string $message,
        ?string $errorCode = null,
        int $httpStatus = 200,
        bool $logout = false,
        array $response = []
    ) {
        parent::__construct($message);
        $this->errorCode = $errorCode;
        $this->httpStatus = $httpStatus;
        $this->logout = $logout;
        $this->response = $response;
    }

    public function getErrorCode(): ?string
    {
        return $this->errorCode;
    }

    public function getHttpStatus(): int
    {
        return $this->httpStatus;
    }

    /**
     * True when the API says the session/token is no longer valid.
     */
    public function shouldLogout(): bool
    {
        return $this->logout;
    }

    /**
     * @return array<string, mixed>
     */
    public function getResponse(): array
    {
        return $this->response;
    }
}
