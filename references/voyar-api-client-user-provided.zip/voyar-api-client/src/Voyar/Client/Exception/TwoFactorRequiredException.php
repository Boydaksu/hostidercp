<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * Login needs a second step: call Auth::tfaVerify() with the partial token.
 */
class TwoFactorRequiredException extends ApiException
{
    private string $partialToken;
    private ?string $partialTokenExpiresAt;

    /**
     * @param array<string, mixed> $response
     */
    public function __construct(
        string $message,
        string $partialToken,
        ?string $partialTokenExpiresAt = null,
        ?string $errorCode = null,
        int $httpStatus = 200,
        array $response = []
    ) {
        parent::__construct($message, $errorCode, $httpStatus, false, $response);
        $this->partialToken = $partialToken;
        $this->partialTokenExpiresAt = $partialTokenExpiresAt;
    }

    public function getPartialToken(): string
    {
        return $this->partialToken;
    }

    public function getPartialTokenExpiresAt(): ?string
    {
        return $this->partialTokenExpiresAt;
    }
}
