<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * Network level failure (DNS, connect, timeout, TLS) or an unparsable response.
 */
class TransportException extends VoyarException
{
}
