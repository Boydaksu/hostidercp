<?php

declare(strict_types=1);

namespace Voyar\Client\Exception;

/**
 * The action needs an extra verification (email/phone/identity) before it can run.
 */
class VerificationRequiredException extends ApiException
{
    /** @var array<string, mixed> */
    private array $verification;

    /**
     * @param array<string, mixed> $verification
     * @param array<string, mixed> $response
     */
    public function __construct(string $message, array $verification, ?string $errorCode, int $httpStatus, array $response)
    {
        parent::__construct($message, $errorCode, $httpStatus, false, $response);
        $this->verification = $verification;
    }

    /**
     * @return array<string, mixed>
     */
    public function getVerification(): array
    {
        return $this->verification;
    }
}
