<?php

declare(strict_types=1);

namespace Voyar\Client\Http;

use Voyar\Client\Config;
use Voyar\Client\Exception\TransportException;

final class CurlTransport implements Transport
{
    private Config $config;

    public function __construct(Config $config)
    {
        if (!function_exists('curl_init')) {
            throw new TransportException('The cURL extension is required.');
        }

        $this->config = $config;
    }

    public function send(string $method, string $url, array $headers, $body, $sink = null): RawResponse
    {
        // File transfers have no fixed duration: they are only cut when they stall.
        $isTransfer = $sink !== null || is_array($body);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $isTransfer ? 0 : $this->config->timeout(),
            CURLOPT_CONNECTTIMEOUT => $this->config->connectTimeout(),
            CURLOPT_SSL_VERIFYPEER => $this->config->verifySsl(),
            CURLOPT_SSL_VERIFYHOST => $this->config->verifySsl() ? 2 : 0,
            CURLOPT_USERAGENT => $this->config->userAgent(),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CUSTOMREQUEST => $method,
        ]);

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }

        if ($isTransfer) {
            curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 1);
            curl_setopt($ch, CURLOPT_LOW_SPEED_TIME, $this->config->timeout());
        }

        $filename = null;
        if ($sink !== null) {
            curl_setopt($ch, CURLOPT_HEADERFUNCTION, static function ($ch, string $line) use (&$filename): int {
                if (stripos($line, 'Content-Disposition:') === 0 && stripos($line, 'attachment') !== false) {
                    $filename = preg_match('/filename="?([^";\r\n]*)/i', $line, $match) === 1 ? basename($match[1]) : '';
                }

                return strlen($line);
            });
            // Only a file goes to the sink; anything else (an error in JSON) is kept as the body.
            $buffer = '';
            curl_setopt($ch, CURLOPT_WRITEFUNCTION, static function ($ch, string $chunk) use (&$filename, &$buffer, $sink): int {
                if ($filename === null) {
                    $buffer .= $chunk;

                    return strlen($chunk);
                }

                return (int) fwrite($sink, $chunk);
            });
        }

        $raw = curl_exec($ch);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);

            throw new TransportException('cURL error: ' . $error);
        }

        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        return $sink !== null ? new RawResponse($status, $buffer, $filename) : new RawResponse($status, (string) $raw);
    }
}
