<?php

declare(strict_types=1);

namespace Voyar\Client\Http;

use Voyar\Client\Exception\TransportException;

interface Transport
{
    /**
     * @param string[]                         $headers Raw header lines ("Name: value")
     * @param string|array<string, mixed>|null $body    Encoded request body, or multipart fields (values may be \CURLFile)
     * @param resource|null                    $sink    Stream a file response (Content-Disposition: attachment) is written
     *                                                  to; the returned response then carries its file name and no body
     *
     * @throws TransportException on network failure
     */
    public function send(string $method, string $url, array $headers, $body, $sink = null): RawResponse;
}
