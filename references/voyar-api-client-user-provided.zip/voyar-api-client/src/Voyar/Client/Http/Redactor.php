<?php

declare(strict_types=1);

namespace Voyar\Client\Http;

/**
 * Masks secrets before anything is handed to the logger.
 */
final class Redactor
{
    private const SENSITIVE_KEYS = [
        'password', 'new_password', 'current_password', 'token', 'partial_token', 'device_token',
        'api_key', 'x-api-key', 'code', 'secret', 'sessiontoken',
        // cloud storage login of an FTP migration, masked as a whole
        'credentials',
    ];

    /**
     * @param array<mixed> $data
     *
     * @return array<mixed>
     */
    public static function mask(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_string($key) && in_array(strtolower($key), self::SENSITIVE_KEYS, true)) {
                $data[$key] = '***';
            } elseif (is_array($value)) {
                $data[$key] = self::mask($value);
            }
        }

        return $data;
    }
}
