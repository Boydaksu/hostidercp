<?php

declare(strict_types=1);

namespace Voyar\Client\Http;

use Voyar\Client\Auth\Credentials;
use Voyar\Client\Auth\InMemoryTokenStore;
use Voyar\Client\Auth\Token;
use Voyar\Client\Auth\TokenStore;
use Voyar\Client\Config;
use Voyar\Client\Exception\ApiException;
use Voyar\Client\Exception\AuthenticationException;
use Voyar\Client\Exception\PermissionDeniedException;
use Voyar\Client\Exception\RateLimitedException;
use Voyar\Client\Exception\TransportException;
use Voyar\Client\Exception\TwoFactorRequiredException;
use Voyar\Client\Exception\VerificationRequiredException;

/**
 * Talks to the Voyar client API: auth headers, encoding, decoding, error mapping,
 * transparent (re-)login and GET retries.
 */
final class HttpClient
{
    private Config $config;
    private Transport $transport;
    private TokenStore $tokens;
    private ?Credentials $credentials;
    /** @var callable|null */
    private $logger = null;

    public function __construct(
        Config $config,
        ?Transport $transport = null,
        ?TokenStore $tokens = null,
        ?Credentials $credentials = null
    ) {
        $this->config = $config;
        $this->transport = $transport ?? new CurlTransport($config);
        $this->tokens = $tokens ?? new InMemoryTokenStore();
        $this->credentials = $credentials;

        if ($config->apiKey() !== null && $this->tokens->get() === null) {
            $this->tokens->save(new Token($config->apiKey()));
        }
    }

    /**
     * @param callable|null $logger function (string $message, array $context): void — context is already redacted
     */
    public function setLogger(?callable $logger): void
    {
        $this->logger = $logger;
    }

    /**
     * @param array<string, mixed> $query
     *
     * @return array<string, mixed>
     */
    public function get(string $path, array $query = [], bool $auth = true): array
    {
        if ($query !== []) {
            $path .= '?' . http_build_query($query);
        }

        return $this->request('GET', $path, null, $auth);
    }

    /**
     * @param array<string, mixed> $params
     *
     * @return array<string, mixed>
     */
    public function post(string $path, array $params = [], bool $auth = true): array
    {
        return $this->request('POST', $path, $params, $auth);
    }

    /**
     * @return array<string, mixed>
     */
    public function delete(string $path, bool $auth = true): array
    {
        return $this->request('DELETE', $path, null, $auth);
    }

    /**
     * GETs a file and writes it to $sink as it arrives (nothing is written when the API answers with an error).
     *
     * @param array<string, mixed> $query
     * @param resource             $sink
     *
     * @return string file name sent by the API ('' when it sent none)
     */
    public function download(string $path, array $query, $sink): string
    {
        if ($query !== []) {
            $path .= '?' . http_build_query($query);
        }

        return (string) ($this->request('GET', $path, null, true, [], $sink)['filename'] ?? '');
    }

    /**
     * POSTs multipart/form-data.
     *
     * @param array<string, mixed>                                    $fields
     * @param array<string, array{path:string, name?:string, type?:string}> $files field name => local file
     *
     * @return array<string, mixed>
     */
    public function upload(string $path, array $fields, array $files): array
    {
        return $this->request('POST', $path, $fields, true, $files);
    }

    public function token(): ?Token
    {
        return $this->tokens->get();
    }

    public function useToken(Token $token): void
    {
        $this->tokens->save($token);
    }

    public function forgetToken(): void
    {
        $this->tokens->clear();
    }

    /**
     * Logs in with the configured credentials and stores the token.
     *
     * @throws TwoFactorRequiredException when the account needs a 2FA code
     */
    public function login(): Token
    {
        if ($this->credentials === null) {
            throw new AuthenticationException('No credentials configured for login.');
        }

        $response = $this->request('POST', '/auth/login', [
            'email' => $this->credentials->email(),
            'password' => $this->credentials->password(),
        ], false);

        $token = Token::fromResponse($response);
        if ($token === null) {
            if (!empty($response['partial_token'])) {
                throw new TwoFactorRequiredException(
                    (string) ($response['message'] ?? 'Two-factor code required.'),
                    (string) $response['partial_token'],
                    isset($response['partial_token_expires_at']) ? (string) $response['partial_token_expires_at'] : null,
                    null,
                    200,
                    $response
                );
            }

            throw new AuthenticationException('Login did not return a token.', null, 200, $response);
        }

        $this->tokens->save($token);

        return $token;
    }

    /**
     * @param array<string, mixed>|null                                 $params
     * @param array<string, array{path:string, name?:string, type?:string}> $files sent as multipart together with $params
     * @param resource|null                                             $sink  see download()
     *
     * @return array<string, mixed>
     */
    private function request(string $method, string $path, ?array $params, bool $auth, array $files = [], $sink = null): array
    {
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . $path;
        }

        $url = $this->config->baseUrl() . $path;
        $body = $params !== null ? http_build_query($params) : null;
        if ($files !== []) {
            $body = (array) $params;
            foreach ($files as $field => $file) {
                $body[$field] = new \CURLFile($file['path'], $file['type'] ?? 'application/octet-stream', $file['name'] ?? basename($file['path']));
            }
        }
        // A download may already have written to the sink, so it is never repeated.
        $maxRetries = $method === 'GET' && $sink === null ? $this->config->maxRetries() : 0;
        $retriedAuth = false;
        $attempt = 0;

        while (true) {
            $headers = $this->buildHeaders($auth, is_string($body));
            $this->log($method . ' ' . $path, $params !== null ? Redactor::mask($params) : []);

            try {
                $raw = $this->transport->send($method, $url, $headers, $body, $sink);
            } catch (TransportException $e) {
                if ($attempt < $maxRetries) {
                    $this->backoff(++$attempt);
                    continue;
                }

                throw $e;
            }

            if ($raw->status() >= 500 && $attempt < $maxRetries) {
                $this->backoff(++$attempt);
                continue;
            }

            if ($raw->isFile()) {
                return ['filename' => $raw->filename()];
            }

            try {
                return $this->decode($raw);
            } catch (AuthenticationException $e) {
                if ($auth && !$retriedAuth && $this->credentials !== null) {
                    $retriedAuth = true;
                    $this->tokens->clear();
                    continue;
                }

                throw $e;
            }
        }
    }

    /**
     * @return string[]
     */
    private function buildHeaders(bool $auth, bool $hasFormBody): array
    {
        $headers = ['Accept: application/json'];

        if ($this->config->language() !== null) {
            $headers[] = 'X-Language: ' . $this->config->language();
        }

        if ($hasFormBody) {
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        if ($auth) {
            $headers[] = 'X-Api-Key: ' . $this->resolveToken();
        }

        return $headers;
    }

    private function resolveToken(): string
    {
        $token = $this->tokens->get();
        if ($token !== null && !$token->isExpired()) {
            return $token->value();
        }

        if ($this->credentials !== null) {
            return $this->login()->value();
        }

        if ($token !== null) {
            throw new AuthenticationException('API token has expired.');
        }

        throw new AuthenticationException('API key is not set. Provide api_key or credentials.');
    }

    /**
     * @return array<string, mixed>
     */
    private function decode(RawResponse $raw): array
    {
        $decoded = json_decode($raw->body(), true);
        if (!is_array($decoded)) {
            throw new TransportException('Invalid JSON response from API (HTTP ' . $raw->status() . ').');
        }

        $this->assertSuccess($decoded, $raw->status());

        return $decoded;
    }

    /**
     * @param array<string, mixed> $body
     */
    private function assertSuccess(array $body, int $httpStatus): void
    {
        if (($body['status'] ?? '') === 'success') {
            return;
        }

        $message = (string) ($body['message'] ?? 'API request failed.');
        $errorCode = isset($body['error']) ? (string) $body['error'] : (isset($body['error_code']) ? (string) $body['error_code'] : null);

        if (!empty($body['partial_token'])) {
            throw new TwoFactorRequiredException(
                $message,
                (string) $body['partial_token'],
                isset($body['partial_token_expires_at']) ? (string) $body['partial_token_expires_at'] : null,
                $errorCode,
                $httpStatus,
                $body
            );
        }

        if ($httpStatus === 429 || $errorCode === 'too_many_requests') {
            throw new RateLimitedException($message, (int) ($body['retry_after'] ?? 0), $body);
        }

        if ($errorCode === 'permission_denied' || $httpStatus === 403) {
            throw new PermissionDeniedException(
                $message,
                isset($body['required_permission']) ? (string) $body['required_permission'] : null,
                $body
            );
        }

        if (!empty($body['logout']) || $httpStatus === 401 || strpos((string) $errorCode, 'auth_provider_') === 0) {
            throw new AuthenticationException($message, $errorCode, $httpStatus, $body);
        }

        if ($errorCode === 'verification_required' || !empty($body['verification_required'])) {
            $verification = $body['verification'] ?? $body;

            throw new VerificationRequiredException($message, (array) $verification, $errorCode, $httpStatus, $body);
        }

        throw new ApiException($message, $errorCode, $httpStatus, false, $body);
    }

    private function backoff(int $attempt): void
    {
        usleep(200000 * $attempt);
    }

    /**
     * @param array<mixed> $context
     */
    private function log(string $message, array $context): void
    {
        if ($this->logger !== null) {
            ($this->logger)($message, $context);
        }
    }
}
