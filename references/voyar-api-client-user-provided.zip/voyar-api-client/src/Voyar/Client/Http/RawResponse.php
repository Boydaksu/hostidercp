<?php

declare(strict_types=1);

namespace Voyar\Client\Http;

final class RawResponse
{
    private int $status;
    private string $body;
    private ?string $filename;

    /**
     * @param string|null $filename set when the body was a file written to the caller's sink (body is then empty)
     */
    public function __construct(int $status, string $body, ?string $filename = null)
    {
        $this->status = $status;
        $this->body = $body;
        $this->filename = $filename;
    }

    public function status(): int
    {
        return $this->status;
    }

    public function body(): string
    {
        return $this->body;
    }

    public function isFile(): bool
    {
        return $this->filename !== null;
    }

    public function filename(): ?string
    {
        return $this->filename;
    }
}
