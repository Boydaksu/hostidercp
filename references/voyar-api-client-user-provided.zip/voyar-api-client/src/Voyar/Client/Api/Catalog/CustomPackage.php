<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;
use Voyar\Client\Model\CustomPackageSpec;

/**
 * /resources/custom-package/* — ratio rules and price quotes for custom packages (auth required).
 */
final class CustomPackage extends AbstractApi
{
    /**
     * Allowed CPU/RAM/Disk/IPv4 ranges for a product group (`custom_package` key in the response).
     *
     * @return array<string, mixed>
     */
    public function options(int $productGroupId): array
    {
        return $this->http->get('/resources/custom-package/options', ['product_group_id' => $productGroupId]);
    }

    /**
     * Validates the selection and returns the hourly/daily cost (`quote` key). No writes.
     *
     * @param string|null $billingType prepaid|ondemand (informational)
     *
     * @return array<string, mixed>
     */
    public function quote(CustomPackageSpec $spec, ?string $billingType = null): array
    {
        $payload = ['custom_package' => $spec->toArray()];
        if ($billingType !== null && $billingType !== '') {
            $payload['billing_type'] = $billingType;
        }

        return $this->http->post('/resources/custom-package/quote', $payload);
    }
}
