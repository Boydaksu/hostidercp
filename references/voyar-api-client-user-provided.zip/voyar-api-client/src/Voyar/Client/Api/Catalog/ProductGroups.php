<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class ProductGroups extends AbstractApi
{
    /**
     * Each group carries `custom_builder_enabled` (custom package support).
     * Pass `include_products => 1` to get the visible products too.
     *
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function search(array $filters = []): array
    {
        return $this->http->get('/resources/productgroups/search', $filters, false);
    }
}
