<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class PhoneCountries extends AbstractApi
{
    /**
     * @return array<string, mixed>
     */
    public function index(): array
    {
        return $this->http->get('/resources/phone-countries', [], false);
    }
}
