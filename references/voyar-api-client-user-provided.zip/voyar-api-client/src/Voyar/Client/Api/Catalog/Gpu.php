<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

/**
 * /resources/gpu/* — GPU models and their VRAM options a product can be ordered with (auth required).
 */
final class Gpu extends AbstractApi
{
    /**
     * `models[].options[]` (id, vram_gb, price, available) for a catalog product (`pid`) or for custom
     * packages (`custom_package` = 1). `available` needs `locationid`; `processor_family` is optional.
     *
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function search(array $filters): array
    {
        return $this->http->get('/resources/gpu/search', $filters);
    }
}
