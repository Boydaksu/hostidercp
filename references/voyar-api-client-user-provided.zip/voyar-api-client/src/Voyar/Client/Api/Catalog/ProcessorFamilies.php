<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class ProcessorFamilies extends AbstractApi
{
    /**
     * Processor families (`processor_families[].code/available`) for a product in a location.
     *
     * @param int|string $productId
     * @param int|string $locationId
     *
     * @return array<string, mixed>
     */
    public function stock($productId, $locationId): array
    {
        return $this->http->get('/resources/processor-families/stock', [
            'pid' => $productId,
            'locationid' => $locationId,
        ], false);
    }
}
