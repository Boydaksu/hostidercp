<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class Fields extends AbstractApi
{
    /**
     * @param int|string $productId
     *
     * @return array<string, mixed>
     */
    public function product($productId): array
    {
        return $this->http->get($this->path('resources', 'fields', 'product', $productId));
    }

    /**
     * @return array<string, mixed>
     */
    public function clients(): array
    {
        return $this->http->get('/resources/fields/clients');
    }
}
