<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class Locations extends AbstractApi
{
    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function search(array $filters = []): array
    {
        return $this->http->get('/resources/locations/search', $filters, false);
    }

    /**
     * @param int|string $id
     *
     * @return array<string, mixed>
     */
    public function get($id): array
    {
        return $this->http->get($this->path('resources', 'locations', 'get', $id), [], false);
    }

    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function stock(array $filters): array
    {
        return $this->http->get('/resources/locations/stock', $filters, false);
    }
}
