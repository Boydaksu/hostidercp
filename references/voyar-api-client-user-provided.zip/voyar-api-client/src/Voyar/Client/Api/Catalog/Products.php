<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Catalog;

use Voyar\Client\Api\AbstractApi;

final class Products extends AbstractApi
{
    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function search(array $filters = []): array
    {
        return $this->http->get('/resources/products/search', $filters, false);
    }

    /**
     * @param int|string $id
     *
     * @return array<string, mixed>
     */
    public function get($id): array
    {
        return $this->http->get($this->path('resources', 'products', 'get', $id), [], false);
    }
}
