<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

use Voyar\Client\Exception\VoyarException;
use Voyar\Client\Http\HttpClient;

/**
 * Base for APIs bound to one service public id. The id is fixed at construction, so scopes
 * can be passed around without leaking state.
 */
abstract class ServiceScopedApi extends AbstractApi
{
    protected string $serviceId;

    public function __construct(HttpClient $http, string $serviceId)
    {
        if (trim($serviceId) === '') {
            throw new VoyarException('Service public id must not be empty.');
        }

        parent::__construct($http);
        $this->serviceId = $serviceId;
    }

    public function serviceId(): string
    {
        return $this->serviceId;
    }
}
