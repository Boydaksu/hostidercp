<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

/**
 * /services/services/addons/* — addons attached to one service.
 */
final class Addons extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function list(): array
    {
        return $this->http->get($this->path('services', 'services', 'addons', 'list', $this->serviceId));
    }

    /**
     * @param int|string $addonId catalog addon id
     *
     * @return array<string, mixed>
     */
    public function assign($addonId, int $quantity = 1): array
    {
        return $this->http->post($this->path('services', 'services', 'addons', 'assign', $this->serviceId), [
            'addonid' => $addonId,
            'qty' => $quantity,
        ]);
    }

    /**
     * @param int|string           $assignmentId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function update($assignmentId, array $data): array
    {
        return $this->http->post($this->path('services', 'services', 'addons', 'update', $this->serviceId, $assignmentId), $data);
    }

    /**
     * Removes an add-on. On a prepaid service it leaves at the end of the paid period, unless
     * `immediate` => 1 is passed (removed now, nothing refunded). On-demand services always remove now.
     *
     * @param int|string           $assignmentId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function remove($assignmentId, array $data = []): array
    {
        return $this->http->post($this->path('services', 'services', 'addons', 'remove', $this->serviceId, $assignmentId), $data);
    }

    /**
     * @param int|string           $assignmentId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function cancelRevoke($assignmentId, array $data = []): array
    {
        return $this->http->post($this->path('services', 'services', 'addons', 'cancel-revoke', $this->serviceId, $assignmentId), $data);
    }
}
