<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class Rdns extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function list(): array
    {
        return $this->http->get($this->path('services', 'rdns', 'list', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $filters page, limit
     *
     * @return array<string, mixed>
     */
    public function history(array $filters = []): array
    {
        return $this->http->get($this->path('services', 'rdns', 'history', $this->serviceId), $filters);
    }

    /** @return array<string, mixed> */
    public function update(string $ipAddress, string $hostname): array
    {
        return $this->http->post($this->path('services', 'rdns', 'update', $this->serviceId), [
            'ipaddress' => $ipAddress,
            'hostname' => $hostname,
        ]);
    }
}
