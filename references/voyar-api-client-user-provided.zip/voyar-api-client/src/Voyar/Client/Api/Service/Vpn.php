<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

/**
 * /services/vpn/* — profiles of one VPN service.
 */
final class Vpn extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function overview(): array
    {
        return $this->http->get($this->path('services', 'vpn', 'overview', $this->serviceId));
    }

    /** @return array<string, mixed> */
    public function profiles(): array
    {
        return $this->http->get($this->path('services', 'vpn', 'profiles', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function createProfile(array $data): array
    {
        return $this->http->post($this->path('services', 'vpn', 'profiles', 'create', $this->serviceId), $data);
    }

    /**
     * @param int|string $profileId
     *
     * @return array<string, mixed>
     */
    public function deleteProfile($profileId): array
    {
        return $this->profileAction('delete', $profileId);
    }

    /**
     * @param int|string $profileId
     *
     * @return array<string, mixed>
     */
    public function changeIp($profileId): array
    {
        return $this->profileAction('change-ip', $profileId);
    }

    /**
     * @param int|string           $profileId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function changeLocation($profileId, array $data): array
    {
        return $this->profileAction('change-location', $profileId, $data);
    }

    /**
     * Writes the profile's configuration file to $sink.
     *
     * @param int|string $profileId
     * @param resource   $sink
     *
     * @return string file name
     */
    public function downloadProfile($profileId, $sink): string
    {
        return $this->http->download($this->path('services', 'vpn', 'profiles', 'download', $this->serviceId, $profileId), [], $sink);
    }

    /**
     * @param int|string $profileId
     *
     * @return array<string, mixed>
     */
    public function bindableServers($profileId): array
    {
        return $this->http->get($this->path('services', 'vpn', 'profiles', 'bindable-servers', $this->serviceId, $profileId));
    }

    /**
     * @param int|string $profileId
     *
     * @return array<string, mixed>
     */
    public function binds($profileId): array
    {
        return $this->http->get($this->path('services', 'vpn', 'profiles', 'binds', $this->serviceId, $profileId));
    }

    /**
     * @param int|string           $profileId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function bindFirewall($profileId, array $data): array
    {
        return $this->profileAction('bind-firewall', $profileId, $data);
    }

    /**
     * @param int|string $profileId
     * @param int|string $bindId
     *
     * @return array<string, mixed>
     */
    public function unbindFirewall($profileId, $bindId): array
    {
        return $this->http->post($this->path('services', 'vpn', 'profiles', 'unbind-firewall', $this->serviceId, $profileId, $bindId));
    }

    /**
     * @param int|string           $profileId
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function profileAction(string $action, $profileId, array $data = []): array
    {
        return $this->http->post($this->path('services', 'vpn', 'profiles', $action, $this->serviceId, $profileId), $data);
    }
}
