<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

/**
 * /services/ftp/* — one FTP storage service: account, file manager, sub-users, IP allow-list,
 * remote downloads, cloud migrations, logs and disk analysis. Paths are relative to the account's home.
 */
final class Ftp extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function overview(): array
    {
        return $this->read(['overview']);
    }

    /** @return array<string, mixed> the new password is in `password` */
    public function resetPassword(): array
    {
        return $this->write(['reset-password']);
    }

    /** @return array<string, mixed> */
    public function files(string $path = ''): array
    {
        return $this->read(['files', 'list'], ['path' => $path]);
    }

    /** @return array<string, mixed> */
    public function readFile(string $path): array
    {
        return $this->read(['files', 'read'], ['path' => $path]);
    }

    /** @return array<string, mixed> */
    public function writeFile(string $path, string $content): array
    {
        return $this->write(['files', 'write'], ['path' => $path, 'content' => $content]);
    }

    /**
     * @param string $directory target directory
     * @param string $localFile file on this machine
     * @param string $name      name the file gets in the directory
     *
     * @return array<string, mixed>
     */
    public function upload(string $directory, string $localFile, string $name): array
    {
        return $this->http->upload(
            $this->path('services', 'ftp', 'files', 'upload', $this->serviceId),
            ['path' => $directory],
            ['file' => ['path' => $localFile, 'name' => $name]]
        );
    }

    /**
     * Writes the file to $sink as it arrives.
     *
     * @param resource $sink
     *
     * @return string file name
     */
    public function download(string $path, $sink): string
    {
        return $this->http->download($this->path('services', 'ftp', 'files', 'download', $this->serviceId), ['path' => $path], $sink);
    }

    /** @return array<string, mixed> */
    public function mkdir(string $path, string $name): array
    {
        return $this->write(['files', 'mkdir'], ['path' => $path, 'name' => $name]);
    }

    /** @return array<string, mixed> */
    public function rename(string $path, string $newName): array
    {
        return $this->write(['files', 'rename'], ['path' => $path, 'new_name' => $newName]);
    }

    /** @return array<string, mixed> */
    public function delete(string $path): array
    {
        return $this->write(['files', 'delete'], ['path' => $path]);
    }

    /** @return array<string, mixed> */
    public function subusers(): array
    {
        return $this->read(['subusers']);
    }

    /**
     * @param array<string, mixed> $data name, directory, password (optional), ip_rules
     *
     * @return array<string, mixed>
     */
    public function createSubuser(array $data): array
    {
        return $this->write(['subusers', 'create'], $data);
    }

    /**
     * Sets the sub-user's password; a new one is generated when none is given.
     *
     * @param int|string $subuserId
     *
     * @return array<string, mixed>
     */
    public function updateSubuser($subuserId, ?string $password = null): array
    {
        return $this->write(['subusers', 'update'], $password !== null ? ['password' => $password] : [], $subuserId);
    }

    /**
     * @param int|string $subuserId
     *
     * @return array<string, mixed>
     */
    public function deleteSubuser($subuserId): array
    {
        return $this->write(['subusers', 'delete'], [], $subuserId);
    }

    /**
     * IP allow-list of the account, or of one sub-user.
     *
     * @param int|string|null $subuserId
     *
     * @return array<string, mixed>
     */
    public function ipRules($subuserId = null): array
    {
        return $this->read(['ip-rules'], $subuserId !== null ? ['subuser_id' => $subuserId] : []);
    }

    /**
     * @param string[]        $rules     IP addresses / CIDR ranges
     * @param int|string|null $subuserId
     *
     * @return array<string, mixed>
     */
    public function saveIpRules(array $rules, $subuserId = null): array
    {
        return $this->write(['ip-rules', 'save'], ['rules' => $rules] + ($subuserId !== null ? ['subuser_id' => $subuserId] : []));
    }

    /** @return array<string, mixed> IPs of the account's other services, offered as allow-list entries */
    public function ipSources(): array
    {
        return $this->read(['ip-rules', 'sources']);
    }

    /**
     * Downloads a URL into the account.
     *
     * @param array<string, mixed> $data url, path, filename (optional)
     *
     * @return array<string, mixed>
     */
    public function startRemote(array $data): array
    {
        return $this->write(['remote', 'start'], $data);
    }

    /** @return array<string, mixed> */
    public function remoteTasks(): array
    {
        return $this->read(['remote', 'list']);
    }

    /**
     * @param int|string $taskId
     *
     * @return array<string, mixed>
     */
    public function cancelRemote($taskId): array
    {
        return $this->write(['remote', 'cancel'], [], $taskId);
    }

    /**
     * @param array<string, mixed> $data provider, credentials
     *
     * @return array<string, mixed>
     */
    public function testMigration(array $data): array
    {
        return $this->write(['migration', 'test'], $data);
    }

    /**
     * @param array<string, mixed> $data provider, credentials, path
     *
     * @return array<string, mixed>
     */
    public function browseMigration(array $data): array
    {
        return $this->write(['migration', 'browse'], $data);
    }

    /**
     * @param array<string, mixed> $data provider, credentials, source_path, dest_path, overwrite
     *
     * @return array<string, mixed>
     */
    public function startMigration(array $data): array
    {
        return $this->write(['migration', 'start'], $data);
    }

    /** @return array<string, mixed> */
    public function migrations(): array
    {
        return $this->read(['migration', 'list']);
    }

    /**
     * @param int|string $migrationId
     *
     * @return array<string, mixed>
     */
    public function cancelMigration($migrationId): array
    {
        return $this->write(['migration', 'cancel'], [], $migrationId);
    }

    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function loginLogs(array $filters = []): array
    {
        return $this->read(['logs', 'login'], $filters);
    }

    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function fileLogs(array $filters = []): array
    {
        return $this->read(['logs', 'files'], $filters);
    }

    /** @return array<string, mixed> */
    public function requestAnalysis(): array
    {
        return $this->write(['analysis', 'request']);
    }

    /** @return array<string, mixed> */
    public function analysis(): array
    {
        return $this->read(['analysis']);
    }

    /**
     * @param string[]             $action route segments after /services/ftp
     * @param array<string, mixed> $query
     *
     * @return array<string, mixed>
     */
    private function read(array $action, array $query = []): array
    {
        return $this->http->get($this->path('services', 'ftp', ...array_merge($action, [$this->serviceId])), $query);
    }

    /**
     * @param string[]             $action route segments after /services/ftp
     * @param array<string, mixed> $data
     * @param int|string|null      $childId sub-user / task / migration id
     *
     * @return array<string, mixed>
     */
    private function write(array $action, array $data = [], $childId = null): array
    {
        $segments = array_merge($action, [$this->serviceId], $childId !== null ? [$childId] : []);

        return $this->http->post($this->path('services', 'ftp', ...$segments), $data);
    }
}
