<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class Backups extends ServiceScopedApi
{
    /**
     * `data` = backups, `snapshots` = snapshots taken with create(), `pending_snapshots` = running jobs
     * with their percentage, `snapshot_count` / `snapshot_limit`.
     *
     * @return array<string, mixed>
     */
    public function list(): array
    {
        return $this->http->get($this->path('services', 'backups', $this->serviceId));
    }

    /**
     * Starts a snapshot, counted against the service's snapshot limit.
     *
     * @param string $mode kept for older callers: the API always takes a snapshot
     *
     * @return array<string, mixed>
     */
    public function create(string $mode = 'snapshot'): array
    {
        return $this->http->post($this->path('services', 'backups', 'create', $this->serviceId), ['mode' => $mode]);
    }

    /**
     * @param string $volid   backup volume id from list()
     * @param string $storage backup storage from list()
     *
     * @return array<string, mixed>
     */
    public function delete(string $volid, string $storage): array
    {
        return $this->http->post($this->path('services', 'backups', 'delete', $this->serviceId), [
            'volid' => $volid,
            'storage' => $storage,
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function restore(string $volid, string $storage): array
    {
        return $this->http->post($this->path('services', 'backups', 'restore', $this->serviceId), [
            'volid' => $volid,
            'storage' => $storage,
        ]);
    }
}
