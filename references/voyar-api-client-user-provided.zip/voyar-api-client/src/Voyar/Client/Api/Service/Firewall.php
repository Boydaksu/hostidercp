<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class Firewall extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function rules(): array
    {
        return $this->http->get($this->path('services', 'firewall', 'rules', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $rule type, action, proto, dport, source, dest, comment, enable
     *
     * @return array<string, mixed>
     */
    public function createRule(array $rule): array
    {
        return $this->http->post($this->path('services', 'firewall', 'rules', 'create', $this->serviceId), $rule);
    }

    /**
     * @param int|string           $position
     * @param array<string, mixed> $rule
     *
     * @return array<string, mixed>
     */
    public function updateRule($position, array $rule): array
    {
        return $this->http->post($this->path('services', 'firewall', 'rules', 'update', $this->serviceId, $position), $rule);
    }

    /**
     * @param int|string $position
     *
     * @return array<string, mixed>
     */
    public function deleteRule($position): array
    {
        return $this->http->post($this->path('services', 'firewall', 'rules', 'delete', $this->serviceId, $position));
    }
}
