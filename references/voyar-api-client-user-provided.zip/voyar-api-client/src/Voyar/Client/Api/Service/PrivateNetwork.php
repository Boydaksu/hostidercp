<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class PrivateNetwork extends ServiceScopedApi
{
    /**
     * Private IP, whether the private network is enabled and the servers that can be allowed.
     *
     * @return array<string, mixed>
     */
    public function overview(): array
    {
        return $this->http->get($this->path('services', 'private-network', 'overview', $this->serviceId));
    }

    /** @return array<string, mixed> */
    public function enable(): array
    {
        return $this->http->post($this->path('services', 'private-network', 'enable', $this->serviceId));
    }

    /**
     * Allow private traffic with another of your servers (both directions).
     *
     * @return array<string, mixed>
     */
    public function allow(string $servicePublicId): array
    {
        return $this->http->post(
            $this->path('services', 'private-network', 'allow', $this->serviceId),
            ['service' => $servicePublicId]
        );
    }

    /** @return array<string, mixed> */
    public function disallow(string $servicePublicId): array
    {
        return $this->http->post(
            $this->path('services', 'private-network', 'disallow', $this->serviceId),
            ['service' => $servicePublicId]
        );
    }
}
