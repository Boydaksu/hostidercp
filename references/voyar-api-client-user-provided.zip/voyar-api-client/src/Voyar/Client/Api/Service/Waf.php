<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class Waf extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function list(): array
    {
        return $this->http->get($this->path('services', 'waf', 'list', $this->serviceId));
    }

    /** @return array<string, mixed> */
    public function toggle(int $bindingId, string $ipAddress): array
    {
        return $this->http->post($this->path('services', 'waf', 'toggle', $this->serviceId), [
            'bindingid' => $bindingId,
            'ipaddress' => $ipAddress,
        ]);
    }
}
