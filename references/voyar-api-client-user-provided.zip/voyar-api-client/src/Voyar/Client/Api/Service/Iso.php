<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

final class Iso extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function list(): array
    {
        return $this->http->get($this->path('services', 'iso', 'list', $this->serviceId));
    }

    /**
     * @param string $encryptedName ISO `encryptedname` from list()
     * @param string $device        e.g. ide2
     *
     * @return array<string, mixed>
     */
    public function mount(string $encryptedName, string $device = 'ide2'): array
    {
        return $this->http->post($this->path('services', 'iso', 'mount', $this->serviceId), [
            'encryptedname' => $encryptedName,
            'device' => $device,
        ]);
    }

    /** @return array<string, mixed> */
    public function unmount(string $device = 'ide2'): array
    {
        return $this->http->post($this->path('services', 'iso', 'unmount', $this->serviceId), ['device' => $device]);
    }
}
