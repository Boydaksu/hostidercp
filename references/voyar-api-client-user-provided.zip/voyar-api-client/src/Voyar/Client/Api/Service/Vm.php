<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

/**
 * /services/vm/* — power, metrics, SSH/RDP, VNC.
 */
final class Vm extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function start(): array
    {
        return $this->action('start');
    }

    /** @return array<string, mixed> */
    public function stop(): array
    {
        return $this->action('stop');
    }

    /** @return array<string, mixed> */
    public function restart(): array
    {
        return $this->action('restart');
    }

    /** @return array<string, mixed> */
    public function status(): array
    {
        return $this->read('status');
    }

    /** @return array<string, mixed> */
    public function loadavg(): array
    {
        return $this->read('loadavg');
    }

    /**
     * Live usage of the server's GPU, read inside the guest (can take up to 40 seconds).
     *
     * @return array<string, mixed> `data.available` is false while the server has no ready GPU
     */
    public function gpuUsage(): array
    {
        return $this->read('gpu-usage');
    }

    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function graphs(array $filters = []): array
    {
        return $this->http->get($this->path('services', 'vm', 'graphs', $this->serviceId), $filters);
    }

    /**
     * Sets (or generates when omitted) the root/administrator password.
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function password(array $data = []): array
    {
        return $this->action('password', $data);
    }

    /** @return array<string, mixed> */
    public function sshStatus(): array
    {
        return $this->read('get-ssh-status');
    }

    /** @return array<string, mixed> */
    public function changeSshPort(int $port): array
    {
        return $this->action('change-ssh-port', ['port' => $port]);
    }

    /** @return array<string, mixed> */
    public function enableSsh(): array
    {
        return $this->action('enable-ssh');
    }

    /** @return array<string, mixed> */
    public function disableSsh(): array
    {
        return $this->action('disable-ssh');
    }

    /** @return array<string, mixed> */
    public function sshKeys(): array
    {
        return $this->read('ssh-keys');
    }

    /**
     * @param int[] $sshKeyIds
     *
     * @return array<string, mixed>
     */
    public function assignSshKeys(array $sshKeyIds): array
    {
        return $this->action('assign-ssh-keys', ['ssh_key_ids' => array_values(array_map('intval', $sshKeyIds))]);
    }

    /** @return array<string, mixed> */
    public function removeSshKey(int $sshKeyId): array
    {
        return $this->http->post($this->path('services', 'vm', 'remove-ssh-key', $this->serviceId, $sshKeyId));
    }

    /** @return array<string, mixed> */
    public function sshPasswordAuthStatus(): array
    {
        return $this->read('get-ssh-password-auth');
    }

    /** @return array<string, mixed> */
    public function enableSshPasswordAuth(): array
    {
        return $this->action('enable-ssh-password-auth');
    }

    /** @return array<string, mixed> */
    public function disableSshPasswordAuth(): array
    {
        return $this->action('disable-ssh-password-auth');
    }

    /** @return array<string, mixed> */
    public function rdpStatus(): array
    {
        return $this->read('get-rdp-port');
    }

    /** @return array<string, mixed> */
    public function changeRdpPort(int $port): array
    {
        return $this->action('change-rdp-port', ['port' => $port]);
    }

    /** @return array<string, mixed> */
    public function enableRdp(): array
    {
        return $this->action('enable-rdp');
    }

    /** @return array<string, mixed> */
    public function disableRdp(): array
    {
        return $this->action('disable-rdp');
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function vnc(array $data = []): array
    {
        return $this->action('vnc', $data);
    }

    /**
     * Creates a one-time noVNC tunnel session (`sessionToken`, `password`).
     *
     * @return array<string, mixed>
     */
    public function createVncSession(): array
    {
        return $this->http->post($this->path('services', 'vm', 'vnc', 'session', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function action(string $name, array $data = []): array
    {
        return $this->http->post($this->path('services', 'vm', $name, $this->serviceId), $data);
    }

    /**
     * @return array<string, mixed>
     */
    private function read(string $name): array
    {
        return $this->http->get($this->path('services', 'vm', $name, $this->serviceId));
    }
}
