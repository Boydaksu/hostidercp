<?php

declare(strict_types=1);

namespace Voyar\Client\Api\Service;

use Voyar\Client\Api\ServiceScopedApi;

/**
 * One-click app install. Task status/cancel are not service scoped: see Services::oneClickTask().
 */
final class OneClick extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function available(): array
    {
        return $this->http->get($this->path('services', 'oneclicks', 'available', $this->serviceId));
    }

    /** @return array<string, mixed> */
    public function installed(): array
    {
        return $this->http->get($this->path('services', 'oneclicks', 'installed', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function install(array $data): array
    {
        return $this->http->post($this->path('services', 'oneclicks', 'install', $this->serviceId), $data);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function remove(array $data): array
    {
        return $this->http->post($this->path('services', 'oneclicks', 'remove', $this->serviceId), $data);
    }
}
