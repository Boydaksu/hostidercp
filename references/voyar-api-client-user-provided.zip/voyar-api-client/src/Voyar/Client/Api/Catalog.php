<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

use Voyar\Client\Api\Catalog\Addons;
use Voyar\Client\Api\Catalog\CustomPackage;
use Voyar\Client\Api\Catalog\Fields;
use Voyar\Client\Api\Catalog\Gpu;
use Voyar\Client\Api\Catalog\Locations;
use Voyar\Client\Api\Catalog\OperatingSystems;
use Voyar\Client\Api\Catalog\PhoneCountries;
use Voyar\Client\Api\Catalog\ProcessorFamilies;
use Voyar\Client\Api\Catalog\ProductGroups;
use Voyar\Client\Api\Catalog\Products;

/**
 * /resources/* — order catalog.
 */
final class Catalog extends AbstractApi
{
    public function products(): Products
    {
        return new Products($this->http);
    }

    public function productGroups(): ProductGroups
    {
        return new ProductGroups($this->http);
    }

    public function addons(): Addons
    {
        return new Addons($this->http);
    }

    public function locations(): Locations
    {
        return new Locations($this->http);
    }

    public function operatingSystems(): OperatingSystems
    {
        return new OperatingSystems($this->http);
    }

    public function processorFamilies(): ProcessorFamilies
    {
        return new ProcessorFamilies($this->http);
    }

    public function fields(): Fields
    {
        return new Fields($this->http);
    }

    public function phoneCountries(): PhoneCountries
    {
        return new PhoneCountries($this->http);
    }

    public function customPackage(): CustomPackage
    {
        return new CustomPackage($this->http);
    }

    public function gpu(): Gpu
    {
        return new Gpu($this->http);
    }
}
