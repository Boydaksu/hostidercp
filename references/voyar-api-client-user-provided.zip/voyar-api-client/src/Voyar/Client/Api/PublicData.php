<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

/**
 * /public/* — data that needs no login.
 */
final class PublicData extends AbstractApi
{
    /**
     * Exchange rates Voyar bills with: `data.usd` / `data.eur` = Turkish lira per unit, `data.updated_at`.
     *
     * @return array<string, mixed>
     */
    public function exchangeRate(): array
    {
        return $this->http->get('/public/exchange-rate', [], false);
    }
}
