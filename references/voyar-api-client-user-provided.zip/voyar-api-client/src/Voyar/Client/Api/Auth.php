<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

use Voyar\Client\Auth\Token;

/**
 * /auth/* — manual login flow (use Client::withCredentials() for the automatic one).
 */
final class Auth extends AbstractApi
{
    /**
     * Stores the token on success. When 2FA is required the response has `tfa_required` + `partial_token`
     * and no token is stored; finish with tfaVerify().
     *
     * @return array<string, mixed>
     */
    public function login(string $email, string $password, ?string $deviceToken = null): array
    {
        $payload = ['email' => $email, 'password' => $password];
        if ($deviceToken !== null && $deviceToken !== '') {
            $payload['device_token'] = $deviceToken;
        }

        return $this->remember($this->http->post('/auth/login', $payload, false));
    }

    /**
     * @return array<string, mixed>
     */
    public function tfaVerify(string $partialToken, string $code, bool $trustThisDevice = false): array
    {
        $payload = ['partial_token' => $partialToken, 'code' => $code];
        if ($trustThisDevice) {
            $payload['trust_this_device'] = 1;
        }

        return $this->remember($this->http->post('/auth/tfa-verify', $payload, false));
    }

    /**
     * Current token + auth context (permissions, client).
     *
     * @return array<string, mixed>
     */
    public function token(): array
    {
        return $this->http->get('/auth/token');
    }

    /**
     * @param array<string, mixed> $response
     *
     * @return array<string, mixed>
     */
    private function remember(array $response): array
    {
        $token = Token::fromResponse($response);
        if ($token !== null && empty($response['tfa_required'])) {
            $this->http->useToken($token);
        }

        return $response;
    }
}
