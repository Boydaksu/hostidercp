<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

use Voyar\Client\Http\HttpClient;

abstract class AbstractApi
{
    protected HttpClient $http;

    public function __construct(HttpClient $http)
    {
        $this->http = $http;
    }

    /**
     * Joins path segments, URL-encoding each one so ids can never alter the route.
     *
     * @param string|int ...$segments
     */
    protected function path(...$segments): string
    {
        return '/' . implode('/', array_map(static function ($segment): string {
            return rawurlencode((string) $segment);
        }, $segments));
    }
}
