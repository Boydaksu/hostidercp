<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

use Voyar\Client\Api\Service\Addons;
use Voyar\Client\Api\Service\Backups;
use Voyar\Client\Api\Service\Firewall;
use Voyar\Client\Api\Service\PrivateNetwork;
use Voyar\Client\Api\Service\Ftp;
use Voyar\Client\Api\Service\Iso;
use Voyar\Client\Api\Service\OneClick;
use Voyar\Client\Api\Service\Rdns;
use Voyar\Client\Api\Service\Vm;
use Voyar\Client\Api\Service\Vpn;
use Voyar\Client\Api\Service\Waf;

/**
 * One service (VM, VPN, FTP) addressed by its public id. Obtain with Client::service($publicId).
 */
final class Service extends ServiceScopedApi
{
    /** @return array<string, mixed> */
    public function get(): array
    {
        return $this->http->get($this->path('services', 'services', 'get', $this->serviceId));
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function update(array $data): array
    {
        return $this->post('update', $data);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function provision(array $data = []): array
    {
        return $this->post('provision', $data);
    }

    /**
     * @param array<string, mixed> $data osid, password, processor_family, gpu_option_id (absent = keep, 0 = remove)...
     *
     * @return array<string, mixed>
     */
    public function reinstall(array $data): array
    {
        return $this->post('reinstall', $data);
    }

    /**
     * @param array<string, mixed> $data days
     *
     * @return array<string, mixed>
     */
    public function extend(array $data): array
    {
        return $this->post('extend', $data);
    }

    /** @return array<string, mixed> */
    public function extendOptions(): array
    {
        return $this->read('extend-options');
    }

    /**
     * Moves the service to another catalog product (`pid`). Custom-package services cannot be upgraded this way.
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function upgrade(array $data): array
    {
        return $this->post('upgrade', $data);
    }

    /** @return array<string, mixed> */
    public function upgradeOptions(): array
    {
        return $this->read('upgrade-options');
    }

    /**
     * GPU options the service can be reinstalled with (`current_option_id`, `models[].options[]`).
     *
     * @param array<string, mixed> $query locationid, processor_family (defaults: the service's own)
     *
     * @return array<string, mixed>
     */
    public function gpuOptions(array $query = []): array
    {
        return $this->http->get($this->path('services', 'services', 'gpu-options', $this->serviceId), $query);
    }

    /** @return array<string, mixed> */
    public function backupAddonOptions(): array
    {
        return $this->read('backup-addon-options');
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function backupAddonChange(array $data): array
    {
        return $this->post('backup-addon-change', $data);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function terminate(array $data = []): array
    {
        return $this->post('terminate', $data);
    }

    /**
     * Cuts access to a VPN / FTP service (profiles, FTP logins) without changing its billing status.
     *
     * @return array<string, mixed>
     */
    public function lock(): array
    {
        return $this->post('lock', []);
    }

    /** @return array<string, mixed> */
    public function unlock(): array
    {
        return $this->post('unlock', []);
    }

    /** @return array<string, mixed> */
    public function terminateOptions(): array
    {
        return $this->read('terminate-options');
    }

    /** @return array<string, mixed> */
    public function billingTypeChangeOptions(): array
    {
        return $this->read('billing-type-change-options');
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function changeBillingType(array $data): array
    {
        return $this->post('change-billing-type', $data);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function cancelBillingTypeChange(array $data = []): array
    {
        return $this->post('cancel-billing-type-change', $data);
    }

    /** @return array<string, mixed> */
    public function sessions(): array
    {
        return $this->read('sessions');
    }

    /** @return array<string, mixed> */
    public function unseenTasks(): array
    {
        return $this->http->get($this->path('services', 'tasks', 'unseen', $this->serviceId));
    }

    public function vm(): Vm
    {
        return new Vm($this->http, $this->serviceId);
    }

    public function iso(): Iso
    {
        return new Iso($this->http, $this->serviceId);
    }

    public function firewall(): Firewall
    {
        return new Firewall($this->http, $this->serviceId);
    }

    public function privateNetwork(): PrivateNetwork
    {
        return new PrivateNetwork($this->http, $this->serviceId);
    }

    public function waf(): Waf
    {
        return new Waf($this->http, $this->serviceId);
    }

    public function backups(): Backups
    {
        return new Backups($this->http, $this->serviceId);
    }

    public function rdns(): Rdns
    {
        return new Rdns($this->http, $this->serviceId);
    }

    public function oneClick(): OneClick
    {
        return new OneClick($this->http, $this->serviceId);
    }

    public function addons(): Addons
    {
        return new Addons($this->http, $this->serviceId);
    }

    public function vpn(): Vpn
    {
        return new Vpn($this->http, $this->serviceId);
    }

    public function ftp(): Ftp
    {
        return new Ftp($this->http, $this->serviceId);
    }

    /**
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    private function post(string $action, array $data): array
    {
        return $this->http->post($this->path('services', 'services', $action, $this->serviceId), $data);
    }

    /**
     * @return array<string, mixed>
     */
    private function read(string $action): array
    {
        return $this->http->get($this->path('services', 'services', $action, $this->serviceId));
    }
}
