<?php

declare(strict_types=1);

namespace Voyar\Client\Api;

/**
 * /services/* collection level: search, create, tasks, VPN and FTP orders. For one service use Client::service().
 */
final class Services extends AbstractApi
{
    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function search(array $filters = []): array
    {
        return $this->http->get('/services/services/search', $filters);
    }

    /** @return array<string, mixed> */
    public function filterOptions(): array
    {
        return $this->http->get('/services/services/filter-options');
    }

    /**
     * @param array<string, mixed> $filters
     *
     * @return array<string, mixed>
     */
    public function logs(array $filters = []): array
    {
        return $this->http->get('/services/services/logs', $filters);
    }

    /**
     * Orders a service. Pass `pid` for a catalog product, or `custom_package` (see CustomPackageSpec::toArray())
     * for a custom package, plus osid, locationid, hostname, type, days, processor_family, gpu_option_id...
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function create(array $data): array
    {
        return $this->http->post('/services/services/create', $data);
    }

    /**
     * @param array<string, mixed> $filters serviceid (public id) is required by the API
     *
     * @return array<string, mixed>
     */
    public function tasks(array $filters): array
    {
        return $this->http->get('/services/tasks/list', $filters);
    }

    /**
     * Status of a one-click install/remove task (numeric task id, not a service id).
     *
     * @param int|string $taskId
     *
     * @return array<string, mixed>
     */
    public function oneClickTask($taskId): array
    {
        return $this->http->get($this->path('services', 'oneclicks', 'status', $taskId));
    }

    /**
     * @param int|string $taskId
     *
     * @return array<string, mixed>
     */
    public function cancelOneClickTask($taskId): array
    {
        return $this->http->post($this->path('services', 'oneclicks', 'cancel', $taskId));
    }

    /**
     * Orders a VPN service.
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function createVpn(array $data): array
    {
        return $this->http->post('/services/vpn/create', $data);
    }

    /** @return array<string, mixed> */
    public function vpnOverviewList(): array
    {
        return $this->http->get('/services/vpn/overview/list');
    }

    /**
     * Orders an FTP storage service: pid (a plan) or custom_gb (a custom size, see ftpCustomConfig()), type,
     * days and ip_rules (at least one allowed IP is required).
     * The account password is only returned here, in `connection.password`.
     *
     * @param array<string, mixed> $data
     *
     * @return array<string, mixed>
     */
    public function createFtp(array $data): array
    {
        return $this->http->post('/services/ftp/create', $data);
    }

    /**
     * Custom FTP storage sizes (`custom`: enabled, min_gb, max_gb, stops = the sizes that can be ordered,
     * tiers = from_gb / to_gb / step_gb / price_per_gb_month; the tier a size falls into prices every GB).
     *
     * @return array<string, mixed>
     */
    public function ftpCustomConfig(): array
    {
        return $this->http->get('/services/ftp/custom/config');
    }

    /** @return array<string, mixed> `quote`: gb, monthly, daily, hourly */
    public function ftpCustomQuote(int $gb): array
    {
        return $this->http->get('/services/ftp/custom/quote', ['gb' => $gb]);
    }

    /** @return array<string, mixed> */
    public function ftpOverviewList(): array
    {
        return $this->http->get('/services/ftp/overview/list');
    }

    /** @return array<string, mixed> `servers`: host, port and location of every active FTP node */
    public function ftpServers(): array
    {
        return $this->http->get('/services/ftp/servers');
    }

    /** @return array<string, mixed> cloud providers an FTP migration can copy from, with their credential fields */
    public function ftpMigrationProviders(): array
    {
        return $this->http->get('/services/ftp/migration/providers');
    }
}
