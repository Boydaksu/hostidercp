<?php

declare(strict_types=1);

namespace Voyar\Client\Auth;

final class Token
{
    private string $value;
    private ?int $expiresAt;

    /**
     * @param int|null $expiresAt Unix timestamp; null = does not expire (static API key)
     */
    public function __construct(string $value, ?int $expiresAt = null)
    {
        $this->value = $value;
        $this->expiresAt = $expiresAt;
    }

    /**
     * Reads the token from an /auth/login|token|tfa-verify response.
     * Returns null while the login is still waiting for a 2FA code.
     *
     * @param array<string, mixed> $response
     */
    public static function fromResponse(array $response): ?self
    {
        $token = $response['token'] ?? null;

        if (is_array($token) && !empty($token['token'])) {
            $expiresAt = isset($token['expired_at']) ? strtotime((string) $token['expired_at']) : false;

            return new self((string) $token['token'], $expiresAt !== false ? $expiresAt : null);
        }

        if (is_string($token) && $token !== '') {
            return new self($token);
        }

        return null;
    }

    public function value(): string
    {
        return $this->value;
    }

    public function expiresAt(): ?int
    {
        return $this->expiresAt;
    }

    public function isExpired(int $skewSeconds = 60): bool
    {
        return $this->expiresAt !== null && $this->expiresAt <= time() + $skewSeconds;
    }
}
