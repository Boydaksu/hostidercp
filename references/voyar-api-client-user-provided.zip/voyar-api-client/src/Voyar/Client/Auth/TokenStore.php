<?php

declare(strict_types=1);

namespace Voyar\Client\Auth;

/**
 * Persistence hook for tokens, so a login can be shared between requests (DB, cache, file...).
 */
interface TokenStore
{
    public function get(): ?Token;

    public function save(Token $token): void;

    public function clear(): void;
}
