<?php

declare(strict_types=1);

namespace Voyar\Client\Auth;

final class InMemoryTokenStore implements TokenStore
{
    private ?Token $token = null;

    public function get(): ?Token
    {
        return $this->token;
    }

    public function save(Token $token): void
    {
        $this->token = $token;
    }

    public function clear(): void
    {
        $this->token = null;
    }
}
