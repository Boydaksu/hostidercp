<?php

declare(strict_types=1);

namespace Voyar\Client\Model;

use Voyar\Client\Exception\VoyarException;

/**
 * A custom (CPU/RAM/Disk/IPv4) package selection for a product group.
 */
final class CustomPackageSpec
{
    private int $productGroupId;
    private int $cpuCores;
    private int $ramGb;
    private int $diskGb;
    private int $ipv4Count;

    public function __construct(int $productGroupId, int $cpuCores, int $ramGb, int $diskGb, int $ipv4Count = 1)
    {
        if ($productGroupId < 1 || $cpuCores < 1 || $ramGb < 1 || $diskGb < 1 || $ipv4Count < 0) {
            throw new VoyarException('Invalid custom package spec.');
        }

        $this->productGroupId = $productGroupId;
        $this->cpuCores = $cpuCores;
        $this->ramGb = $ramGb;
        $this->diskGb = $diskGb;
        $this->ipv4Count = $ipv4Count;
    }

    public function productGroupId(): int
    {
        return $this->productGroupId;
    }

    public function cpuCores(): int
    {
        return $this->cpuCores;
    }

    public function ramGb(): int
    {
        return $this->ramGb;
    }

    public function diskGb(): int
    {
        return $this->diskGb;
    }

    public function ipv4Count(): int
    {
        return $this->ipv4Count;
    }

    /**
     * Shape expected by `custom_package` in services/create and by custom-package/quote.
     *
     * @return array<string, int>
     */
    public function toArray(): array
    {
        return [
            'product_group_id' => $this->productGroupId,
            'cpu_cores' => $this->cpuCores,
            'ram_gb' => $this->ramGb,
            'disk_gb' => $this->diskGb,
            'ipv4_count' => $this->ipv4Count,
        ];
    }
}
