<?php

declare(strict_types=1);

namespace Voyar\Client;

use Voyar\Client\Exception\VoyarException;

/**
 * Immutable client configuration.
 */
final class Config
{
    public const DEFAULT_BASE_URL = 'https://api.voyar.net/client';

    private string $baseUrl;
    private ?string $apiKey;
    private ?string $language;
    private int $timeout;
    private int $connectTimeout;
    private bool $verifySsl;
    private string $userAgent;
    private int $maxRetries;

    public function __construct(
        string $baseUrl = self::DEFAULT_BASE_URL,
        ?string $apiKey = null,
        ?string $language = null,
        int $timeout = 30,
        int $connectTimeout = 10,
        bool $verifySsl = true,
        string $userAgent = 'voyar-api-client-php/2.0',
        int $maxRetries = 2
    ) {
        $baseUrl = rtrim(trim($baseUrl), '/');
        if ($baseUrl === '') {
            throw new VoyarException('base_url is required.');
        }

        $this->baseUrl = $baseUrl;
        $this->apiKey = $apiKey !== null && $apiKey !== '' ? $apiKey : null;
        $this->language = $language !== null && $language !== '' ? $language : null;
        $this->timeout = max(1, $timeout);
        $this->connectTimeout = max(1, $connectTimeout);
        $this->verifySsl = $verifySsl;
        $this->userAgent = $userAgent;
        $this->maxRetries = max(0, $maxRetries);
    }

    /**
     * Keys: base_url, api_key, language, timeout, connect_timeout, verify_ssl, user_agent, max_retries.
     *
     * @param array<string, mixed> $config
     */
    public static function fromArray(array $config): self
    {
        return new self(
            (string) ($config['base_url'] ?? self::DEFAULT_BASE_URL),
            isset($config['api_key']) ? (string) $config['api_key'] : null,
            isset($config['language']) ? (string) $config['language'] : null,
            (int) ($config['timeout'] ?? 30),
            (int) ($config['connect_timeout'] ?? 10),
            (bool) ($config['verify_ssl'] ?? true),
            (string) ($config['user_agent'] ?? 'voyar-api-client-php/2.0'),
            (int) ($config['max_retries'] ?? 2)
        );
    }

    public function baseUrl(): string
    {
        return $this->baseUrl;
    }

    public function apiKey(): ?string
    {
        return $this->apiKey;
    }

    public function language(): ?string
    {
        return $this->language;
    }

    public function timeout(): int
    {
        return $this->timeout;
    }

    public function connectTimeout(): int
    {
        return $this->connectTimeout;
    }

    public function verifySsl(): bool
    {
        return $this->verifySsl;
    }

    public function userAgent(): string
    {
        return $this->userAgent;
    }

    public function maxRetries(): int
    {
        return $this->maxRetries;
    }
}
