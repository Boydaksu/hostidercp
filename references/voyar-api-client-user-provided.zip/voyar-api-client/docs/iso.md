# ISO

```php
$iso = $voyar->service('VM-1')->iso();
$list = $iso->list();
$iso->mount($encryptedName, 'ide2');   // $encryptedName: list() yanıtındaki ISO'nun encryptedname değeri
$iso->unmount('ide2');
```

| SDK | HTTP | Path |
|-----|------|------|
| `list()` | GET | `/services/iso/list/:id` |
| `mount($encryptedName, $device = 'ide2')` | POST | `/services/iso/mount/:id` |
| `unmount($device = 'ide2')` | POST | `/services/iso/unmount/:id` |
