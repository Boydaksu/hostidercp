# Auth

```php
// Otomatik (önerilen): ilk istekte login, süre dolunca yeniden login
$voyar = Client::withCredentials($email, $password, $tokenStore);

// Manuel akış
$response = $voyar->auth()->login($email, $password);
if (!empty($response['tfa_required'])) {
    $voyar->auth()->tfaVerify($response['partial_token'], '123456', true);   // true = bu cihaza güven
}
$voyar->auth()->token();   // token + izin/bağlam bilgisi
```

| SDK | HTTP | Path | Auth |
|-----|------|------|------|
| `auth()->login($email, $password, $deviceToken = null)` | POST | `/auth/login` | Hayır |
| `auth()->tfaVerify($partialToken, $code, $trust = false)` | POST | `/auth/tfa-verify` | Hayır |
| `auth()->token()` | GET | `/auth/token` | Evet |

Login yanıtı: `token.token`, `token.expired_at` (6 saat). `withCredentials` ile 2FA gerekirse `TwoFactorRequiredException` fırlatılır.
