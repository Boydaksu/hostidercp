# One-Click kurulum

```php
$oc = $voyar->service('VM-1')->oneClick();
$oc->available();
$result = $oc->install(['oneclick_id' => 3, 'fields' => ['domain' => 'example.com']]);
$voyar->services()->oneClickTask($result['data']['task_id']);   // durum (görev id'si ile)
```

| SDK | HTTP | Path |
|-----|------|------|
| `oneClick()->available()` `installed()` | GET | `/services/oneclicks/{available,installed}/:id` |
| `oneClick()->install($data)` `remove($data)` | POST | `/services/oneclicks/{install,remove}/:id` |
| `services()->oneClickTask($taskId)` | GET | `/services/oneclicks/status/:taskId` |
| `services()->cancelOneClickTask($taskId)` | POST | `/services/oneclicks/cancel/:taskId` |

`status` ve `cancel` **görev (task) id'si** alır, servis id'si değil.
