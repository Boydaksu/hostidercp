# Reverse DNS

```php
$rdns = $voyar->service('VM-1')->rdns();
$rdns->list();
$rdns->update('203.0.113.10', 'mail.example.com');
$rdns->history(['page' => 1, 'limit' => 10]);
```

| SDK | HTTP | Path |
|-----|------|------|
| `list()` | GET | `/services/rdns/list/:id` |
| `history($filters)` | GET | `/services/rdns/history/:id` (`page`, `limit`, `status`, `ipaddress`) |
| `update($ipAddress, $hostname)` | POST | `/services/rdns/update/:id` |
