# Katalog (`$voyar->catalog()`)

| SDK | HTTP | Path | Auth |
|-----|------|------|------|
| `products()->search($f)` / `get($id)` | GET | `/resources/products/search`, `/get/:id` | Hayır |
| `productGroups()->search($f)` | GET | `/resources/productgroups/search` (`custom_builder_enabled`, `include_products=1`) | Hayır |
| `addons()->search($f)` / `get($id)` | GET | `/resources/addon/search`, `/get/:id` | Evet |
| `locations()->search($f)` / `get($id)` / `stock($f)` | GET | `/resources/locations/…` | Hayır |
| `operatingSystems()->index()` | GET | `/resources/operatingsystems` (`families[].operatingsystems[]`) | Hayır |
| `processorFamilies()->stock($pid, $locationId)` | GET | `/resources/processor-families/stock` (`processor_families[].code/available`) | Hayır |
| `fields()->product($pid)` / `clients()` | GET | `/resources/fields/…` | Evet |
| `phoneCountries()->index()` | GET | `/resources/phone-countries` | Hayır |
| `customPackage()->options($groupId)` | GET | `/resources/custom-package/options` | Evet |
| `customPackage()->quote($spec, $billingType)` | POST | `/resources/custom-package/quote` | Evet |
| `gpu()->search($f)` | GET | `/resources/gpu/search` (`pid` ya da `custom_package=1`, `locationid`, `processor_family`) | Evet |

## Genel veriler (`$voyar->publicData()`)

| SDK | HTTP | Path | Auth |
|-----|------|------|------|
| `exchangeRate()` | GET | `/public/exchange-rate` (`data.usd`, `data.eur` = 1 birimin ₺ karşılığı, `data.updated_at`) | Hayır |

## Custom package

Yalnızca `custom_builder_enabled = 1` ürün grupları için. `options()` → `custom_package` anahtarı altında kurallar:
`cpu_min/max/step`, `ram_per_core_min_gb/max_gb`, `ram_total_min_gb/max_gb`, `ram_step_gb`, `disk_per_ram_min_gb/max_gb`,
`disk_total_min_gb/max_gb`, `disk_step_gb`, `ipv4_min/max/step`.

`quote()` → `quote` anahtarı: `valid`, `reason` (geçersizse), `ram_allowed_min/max`, `disk_allowed_min/max`, `ipv4_allowed_min/max`,
`hourly_price`, `daily_price`. Fiyatlar sunucu tarafında hesaplanır; istemciden gelen fiyat alanları yok sayılır.

## GPU

`gpu()->search()` → `eligible`, `models[]` (`id`, `code`, `name`, `description`, `image`, `options[]`); her seçenek `id`, `vram_gb`,
`price`, `available`. Stok (`available`) lokasyona bağlıdır: `locationid` verilmezse tüm seçenekler `false` döner. Sipariş için
seçeneğin `id` değeri `services()->create()` içinde `gpu_option_id` olarak gönderilir; işletim sistemi `supports_gpu` olmalıdır.
