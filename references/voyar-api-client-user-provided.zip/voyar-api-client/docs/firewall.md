# Firewall

```php
$fw = $voyar->service('VM-1')->firewall();
$fw->rules();
$fw->createRule(['type' => 'in', 'action' => 'ACCEPT', 'proto' => 'tcp', 'dport' => '443', 'enable' => 1]);
$fw->updateRule(3, ['enable' => 0]);
$fw->deleteRule(3);
```

| SDK | HTTP | Path |
|-----|------|------|
| `rules()` | GET | `/services/firewall/rules/:id` |
| `createRule($rule)` | POST | `/services/firewall/rules/create/:id` |
| `updateRule($pos, $rule)` | POST | `/services/firewall/rules/update/:id/:pos` |
| `deleteRule($pos)` | POST | `/services/firewall/rules/delete/:id/:pos` |
