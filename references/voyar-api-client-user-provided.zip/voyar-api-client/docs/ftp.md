# FTP

```php
$created = $voyar->services()->createFtp(['pid' => 12, 'type' => 'prepaid', 'days' => 30, 'ip_rules' => ['203.0.113.10']]);
$created['connection'];                       // host, port, username, password (şifre yalnızca burada döner)

$custom = $voyar->services()->ftpCustomConfig()['custom'];   // enabled, min_gb, max_gb, stops, tiers
$voyar->services()->ftpCustomQuote(750)['quote'];            // gb, monthly, daily, hourly
$voyar->services()->createFtp(['custom_gb' => 750, 'type' => 'prepaid', 'days' => 30, 'ip_rules' => ['203.0.113.10']]);

$ftp = $voyar->service('FTP-1')->ftp();
$ftp->overview();
$ftp->files('docs');
$ftp->upload('docs', '/tmp/php123', 'rapor.pdf');
$ftp->download('docs/rapor.pdf', fopen('php://output', 'wb'));
$ftp->saveIpRules(['203.0.113.10', '198.51.100.0/24']);

$voyar->service('FTP-1')->lock();             // erişimi keser, faturalama durumu değişmez (VPN için de geçerli)
$voyar->service('FTP-1')->unlock();
```

Özel boyut yalnızca `custom.stops` içindeki değerlerden biri olabilir; fiyat hacim kademelidir (boyutun düştüğü kademenin GB fiyatı tüm alana uygulanır), günlük = aylık / 30.

Yollar hesabın ev dizinine görelidir. `download()` dosyayı verilen akışa yazar; API hata dönerse akışa bir şey yazılmaz ve `ApiException` fırlatılır.

| SDK | HTTP | Path |
|-----|------|------|
| `services()->createFtp($data)` | POST | `/services/ftp/create` (`pid` = plan ya da `custom_gb` = özel boyut) |
| `services()->ftpCustomConfig()` `services()->ftpCustomQuote($gb)` | GET | `/services/ftp/custom/{config,quote}` |
| `services()->ftpOverviewList()` `services()->ftpServers()` `services()->ftpMigrationProviders()` | GET | `/services/ftp/{overview/list,servers,migration/providers}` |
| `overview()` | GET | `/services/ftp/overview/:id` |
| `resetPassword()` | POST | `/services/ftp/reset-password/:id` |
| `files($path)` `readFile($path)` `download($path, $sink)` | GET | `/services/ftp/files/{list,read,download}/:id?path=` |
| `writeFile($path, $content)` `mkdir($path, $name)` `rename($path, $newName)` `delete($path)` | POST | `/services/ftp/files/{write,mkdir,rename,delete}/:id` |
| `upload($directory, $localFile, $name)` | POST (multipart) | `/services/ftp/files/upload/:id` |
| `subusers()` | GET | `/services/ftp/subusers/:id` |
| `createSubuser($data)` | POST | `/services/ftp/subusers/create/:id` |
| `updateSubuser($sid, $password)` `deleteSubuser($sid)` | POST | `/services/ftp/subusers/{update,delete}/:id/:sid` |
| `ipRules($sid)` `ipSources()` | GET | `/services/ftp/ip-rules/:id`, `/services/ftp/ip-rules/sources/:id` |
| `saveIpRules($rules, $sid)` | POST | `/services/ftp/ip-rules/save/:id` |
| `startRemote($data)` `cancelRemote($taskId)` | POST | `/services/ftp/remote/start/:id`, `/services/ftp/remote/cancel/:id/:taskId` |
| `remoteTasks()` | GET | `/services/ftp/remote/list/:id` |
| `testMigration($data)` `browseMigration($data)` `startMigration($data)` | POST | `/services/ftp/migration/{test,browse,start}/:id` |
| `migrations()` `cancelMigration($mid)` | GET / POST | `/services/ftp/migration/list/:id`, `/services/ftp/migration/cancel/:id/:mid` |
| `loginLogs($filters)` `fileLogs($filters)` | GET | `/services/ftp/logs/{login,files}/:id` |
| `requestAnalysis()` `analysis()` | POST / GET | `/services/ftp/analysis/request/:id`, `/services/ftp/analysis/:id` |
| `service($id)->lock()` `unlock()` | POST | `/services/services/{lock,unlock}/:id` |
