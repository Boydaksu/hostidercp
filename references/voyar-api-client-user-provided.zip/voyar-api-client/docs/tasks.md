# Görevler

```php
$voyar->services()->tasks(['serviceid' => 'VM-1']);
$voyar->service('VM-1')->unseenTasks();
```

| SDK | HTTP | Path |
|-----|------|------|
| `services()->tasks($filters)` | GET | `/services/tasks/list` (`serviceid` = public id zorunlu) |
| `service($id)->unseenTasks()` | GET | `/services/tasks/unseen/:id` |

VM'in aktif görevi `vm()->status()` yanıtında `task` anahtarıyla da gelir.
