# VM

```php
$vm = $voyar->service('VM-123456')->vm();
$vm->start(); $vm->stop(); $vm->restart();
$status = $vm->status();
$graphs = $vm->graphs(['timeframe' => 'hour']);
$vm->password();                          // parola üretir
$vm->password(['password' => 'S3cret!']); // verilen parolayı ayarlar
$vm->changeSshPort(2222);
$session = $vm->createVncSession();       // sessionToken + password
```

| SDK | HTTP | Path (`:id` = servis public id) |
|-----|------|------|
| `start() stop() restart()` | POST | `/services/vm/{start,stop,restart}/:id` |
| `status()` `loadavg()` | GET | `/services/vm/{status,loadavg}/:id` |
| `gpuUsage()` | GET | `/services/vm/gpu-usage/:id` (`data.available`, `data.gpu_usage`; misafir içinde okunur, 40 sn sürebilir) |
| `graphs($filters)` | GET | `/services/vm/graphs/:id` |
| `password($data)` | POST | `/services/vm/password/:id` |
| `sshStatus()` | GET | `/services/vm/get-ssh-status/:id` |
| `changeSshPort($port)` `enableSsh()` `disableSsh()` | POST | `/services/vm/{change-ssh-port,enable-ssh,disable-ssh}/:id` |
| `sshKeys()` | GET | `/services/vm/ssh-keys/:id` |
| `assignSshKeys($ids)` | POST | `/services/vm/assign-ssh-keys/:id` |
| `removeSshKey($keyId)` | POST | `/services/vm/remove-ssh-key/:id/:keyId` |
| `sshPasswordAuthStatus()` `enableSshPasswordAuth()` `disableSshPasswordAuth()` | GET/POST | `/services/vm/{get,enable,disable}-ssh-password-auth/:id` |
| `rdpStatus()` | GET | `/services/vm/get-rdp-port/:id` |
| `changeRdpPort($port)` `enableRdp()` `disableRdp()` | POST | `/services/vm/{change-rdp-port,enable-rdp,disable-rdp}/:id` |
| `vnc($data)` | POST | `/services/vm/vnc/:id` |
| `createVncSession()` | POST | `/services/vm/vnc/session/:id` |
