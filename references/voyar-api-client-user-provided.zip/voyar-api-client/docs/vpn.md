# VPN

```php
$voyar->services()->createVpn([...]);
$voyar->services()->vpnOverviewList();

$vpn = $voyar->service('VPN-1')->vpn();
$vpn->overview();
$vpn->createProfile(['name' => 'laptop']);
$vpn->changeIp($profileId);
$vpn->downloadProfile($profileId, $sink);     // dosyayı $sink akışına yazar, dosya adını döner
```

| SDK | HTTP | Path |
|-----|------|------|
| `overview()` `profiles()` | GET | `/services/vpn/overview/:id`, `/services/vpn/profiles/:id` |
| `createProfile($data)` | POST | `/services/vpn/profiles/create/:id` |
| `deleteProfile($pid)` `changeIp($pid)` | POST | `/services/vpn/profiles/{delete,change-ip}/:id/:pid` |
| `changeLocation($pid, $data)` | POST | `/services/vpn/profiles/change-location/:id/:pid` |
| `downloadProfile($pid, $sink)` `bindableServers($pid)` `binds($pid)` | GET | `/services/vpn/profiles/{download,bindable-servers,binds}/:id/:pid` |
| `bindFirewall($pid, $data)` | POST | `/services/vpn/profiles/bind-firewall/:id/:pid` |
| `unbindFirewall($pid, $bindId)` | POST | `/services/vpn/profiles/unbind-firewall/:id/:pid/:bindId` |
