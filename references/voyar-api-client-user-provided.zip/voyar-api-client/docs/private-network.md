# Private Network

Sunucularınız arasında yerel iletişim için private IP. Erişim yalnızca izin verdiğiniz kendi
sunucularınız arasında ve karşılıklı açılır.

```php
$net = $voyar->service('VM-1')->privateNetwork();
$net->overview();          // private_network: enabled, ip, netmask, peers[]
$net->enable();            // mevcut sunucuda etkinleştirir (adres için yeniden başlatma gerekir)
$net->allow('VM-2');       // VM-1 <-> VM-2 private erişimi açılır
$net->disallow('VM-2');
```

| SDK | HTTP | Path |
|-----|------|------|
| `overview()` | GET | `/services/private-network/overview/:id` |
| `enable()` | POST | `/services/private-network/enable/:id` |
| `allow($publicId)` | POST | `/services/private-network/allow/:id` |
| `disallow($publicId)` | POST | `/services/private-network/disallow/:id` |

Servis yanıtındaki `private_ip` alanı (`get`, `search`) adresi doğrudan verir; etkin değilse `null`.
