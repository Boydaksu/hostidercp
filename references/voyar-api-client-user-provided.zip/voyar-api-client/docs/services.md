# Servisler

Koleksiyon seviyesi: `$voyar->services()`. Tek servis: `$voyar->service($publicId)`.

```php
$voyar->services()->search(['page' => 1]);
$created = $voyar->services()->create(['pid' => 5, 'osid' => 12, 'locationid' => 2, 'hostname' => 'srv1', 'type' => 'prepaid', 'days' => 30]);

$svc = $voyar->service('VM-123456');
$svc->get();
$svc->extend(['days' => 30]);
$svc->upgrade(['pid' => 7]);
$svc->reinstall(['osid' => 14]);
$svc->terminate();
```

## Koleksiyon

| SDK | HTTP | Path |
|-----|------|------|
| `services()->search($f)` | GET | `/services/services/search` |
| `services()->filterOptions()` | GET | `/services/services/filter-options` |
| `services()->logs($f)` | GET | `/services/services/logs` |
| `services()->create($data)` | POST | `/services/services/create` |
| `services()->tasks($f)` | GET | `/services/tasks/list` (`serviceid` zorunlu) |
| `services()->oneClickTask($taskId)` / `cancelOneClickTask($taskId)` | GET / POST | `/services/oneclicks/status|cancel/:taskId` |
| `services()->createVpn($data)` / `vpnOverviewList()` | POST / GET | `/services/vpn/create`, `/services/vpn/overview/list` |

`create` — katalog ürünü için `pid`, custom paket için `custom_package` ([resources.md](resources.md)). Ortak alanlar:
`osid`, `locationid`, `hostname`, `type` (`prepaid`/`ondemand`), `days`, `processor_family`, `gpu_option_id` (isteğe bağlı, [resources.md](resources.md)).

## Tek servis (`/services/services/{action}/:id`)

`get`, `update`, `provision`, `reinstall`, `extend`, `extendOptions`, `upgrade`, `upgradeOptions`, `gpuOptions`, `backupAddonOptions`, `backupAddonChange`,
`terminate`, `terminateOptions`, `lock`, `unlock` (VPN / FTP), `billingTypeChangeOptions`, `changeBillingType`, `cancelBillingTypeChange`, `sessions`; `unseenTasks()` → `/services/tasks/unseen/:id`.

Alt kaynaklar: `vm() iso() firewall() privateNetwork() waf() backups() rdns() oneClick() addons() vpn()`.

## Addons — `service($id)->addons()`

| SDK | Path |
|-----|------|
| `list()` | GET `/services/services/addons/list/:id` |
| `assign($addonId, $qty = 1)` | POST `…/addons/assign/:id` |
| `update($assignmentId, $data)` | POST `…/addons/update/:id/:assignmentId` |
| `remove($assignmentId, $data = [])` | POST `…/addons/remove/:id/:assignmentId` |
| `cancelRevoke($assignmentId, $data = [])` | POST `…/addons/cancel-revoke/:id/:assignmentId` |
