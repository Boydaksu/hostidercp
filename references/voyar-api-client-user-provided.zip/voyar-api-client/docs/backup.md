# Yedekler

```php
$backups = $voyar->service('VM-1')->backups();
$list = $backups->list();
$backups->create();                                 // her zaman snapshot alır
$backups->restore($volid, $storage);
$backups->delete($volid, $storage);
```

| SDK | HTTP | Path |
|-----|------|------|
| `list()` | GET | `/services/backups/:id` |
| `create()` | POST | `/services/backups/create/:id` |
| `delete($volid, $storage)` | POST | `/services/backups/delete/:id` |
| `restore($volid, $storage)` | POST | `/services/backups/restore/:id` |

`volid` ve `storage` değerleri `list()` yanıtından alınır.

`list()` yanıtı: `data` (yedekler), `snapshots` (`create()` ile alınanlar), `pending_snapshots` (süren işler: `status`, yüzde),
`snapshot_count`, `snapshot_limit` (0 = snapshot hakkı yok). `create()` depolamayı ve modu sunucuda seçer; süren işler de limite sayılır.
