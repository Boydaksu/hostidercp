# WAF

```php
$waf = $voyar->service('VM-1')->waf();
$waf->list();
$waf->toggle($bindingId, '203.0.113.10');
```

| SDK | HTTP | Path |
|-----|------|------|
| `list()` | GET | `/services/waf/list/:id` |
| `toggle($bindingId, $ipAddress)` | POST | `/services/waf/toggle/:id` |
